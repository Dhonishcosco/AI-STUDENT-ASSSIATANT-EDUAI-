export type NavMode =
  | 'chat'
  | 'study'
  | 'career'
  | 'placement'
  | 'resume'
  | 'aptitude'
  | 'interview'
  | 'skills'
  | 'progress'
  | 'profile';
