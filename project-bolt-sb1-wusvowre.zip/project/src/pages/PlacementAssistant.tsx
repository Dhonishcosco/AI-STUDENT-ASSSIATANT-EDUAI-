import { useState } from 'react';
import { Target, CheckCircle2, AlertCircle, TrendingUp, Building2, Star } from 'lucide-react';

type Criterion = {
  id: string;
  label: string;
  description: string;
  weight: number;
  score: number;
};

const initialCriteria: Criterion[] = [
  { id: 'dsa', label: 'DSA & Problem Solving', description: 'LeetCode, HackerRank, competitive programming', weight: 25, score: 5 },
  { id: 'tech', label: 'Technical Skills', description: 'Programming languages, frameworks, tools', weight: 30, score: 5 },
  { id: 'projects', label: 'Projects & Portfolio', description: 'Quality and quantity of projects built', weight: 20, score: 5 },
  { id: 'communication', label: 'Communication Skills', description: 'Verbal, written, and presentation skills', weight: 15, score: 5 },
  { id: 'aptitude', label: 'Aptitude Preparation', description: 'Quant, logical reasoning, verbal ability', weight: 10, score: 5 },
];

const companyTiers = [
  {
    tier: 'Tier 1',
    companies: ['Google', 'Microsoft', 'Amazon', 'Meta', 'Apple'],
    minScore: 82,
    package: '25–50 LPA',
    color: 'text-amber-400',
    bg: 'bg-amber-500/10',
    border: 'border-amber-500/20',
  },
  {
    tier: 'Tier 2',
    companies: ['Flipkart', 'Adobe', 'Uber', 'Zomato', 'Swiggy'],
    minScore: 65,
    package: '15–30 LPA',
    color: 'text-blue-400',
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/20',
  },
  {
    tier: 'Tier 3',
    companies: ['TCS', 'Infosys', 'Wipro', 'Cognizant', 'HCL'],
    minScore: 40,
    package: '4–10 LPA',
    color: 'text-emerald-400',
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/20',
  },
];

function getReadinessLabel(score: number): { label: string; color: string; bg: string } {
  if (score >= 81) return { label: 'Highly Competitive', color: 'text-amber-400', bg: 'bg-amber-500/10' };
  if (score >= 61) return { label: 'Placement Ready', color: 'text-emerald-400', bg: 'bg-emerald-500/10' };
  if (score >= 41) return { label: 'Developing', color: 'text-blue-400', bg: 'bg-blue-500/10' };
  return { label: 'Beginner', color: 'text-slate-400', bg: 'bg-slate-500/10' };
}

export default function PlacementAssistant() {
  const [criteria, setCriteria] = useState<Criterion[]>(initialCriteria);
  const [evaluated, setEvaluated] = useState(false);

  const totalScore = Math.round(
    criteria.reduce((acc, c) => acc + (c.score / 10) * c.weight, 0)
  );

  const readiness = getReadinessLabel(totalScore);

  const strengths = criteria.filter((c) => c.score >= 7).map((c) => c.label);
  const weaknesses = criteria.filter((c) => c.score <= 4).map((c) => c.label);

  const eligibleTiers = companyTiers.filter((t) => totalScore >= t.minScore);

  function updateScore(id: string, score: number) {
    setCriteria((prev) => prev.map((c) => (c.id === id ? { ...c, score } : c)));
    setEvaluated(false);
  }

  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-4xl mx-auto w-full">
      <div className="mb-8">
        <h2 className="font-display font-bold text-white text-2xl mb-1">Placement Readiness Evaluator</h2>
        <p className="text-slate-500 text-sm">Rate yourself on each criterion to get your personalized placement score.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Criteria */}
        <div className="lg:col-span-2 space-y-4">
          {criteria.map((criterion) => (
            <div key={criterion.id} className="card p-4 rounded-xl animate-fade-in">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="font-medium text-slate-200 text-sm">{criterion.label}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{criterion.description}</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <span className="text-xs text-slate-500">Weight: {criterion.weight}%</span>
                  <span className={`badge text-sm font-bold ${
                    criterion.score >= 7 ? 'bg-emerald-500/10 text-emerald-400' :
                    criterion.score >= 5 ? 'bg-blue-500/10 text-blue-400' :
                    'bg-rose-500/10 text-rose-400'
                  }`}>{criterion.score}/10</span>
                </div>
              </div>
              <input
                type="range" min={1} max={10} step={1}
                value={criterion.score}
                onChange={(e) => updateScore(criterion.id, parseInt(e.target.value))}
                className="w-full accent-blue-500 h-2 rounded-full cursor-pointer"
              />
              <div className="flex justify-between mt-1">
                <span className="text-xs text-slate-600">Beginner (1)</span>
                <span className="text-xs text-slate-600">Expert (10)</span>
              </div>
            </div>
          ))}

          <button
            onClick={() => setEvaluated(true)}
            className="btn-primary w-full flex items-center justify-center gap-2 py-3 mt-2"
          >
            <Target size={16} />
            Evaluate My Readiness
          </button>
        </div>

        {/* Score panel */}
        <div className="space-y-4">
          {/* Score circle */}
          <div className="card p-6 rounded-xl text-center">
            <div className="relative w-28 h-28 mx-auto mb-4">
              <svg className="w-28 h-28 -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" fill="none" stroke="#1e293b" strokeWidth="10" />
                <circle
                  cx="50" cy="50" r="42" fill="none"
                  stroke={totalScore >= 81 ? '#f59e0b' : totalScore >= 61 ? '#10b981' : totalScore >= 41 ? '#3b82f6' : '#64748b'}
                  strokeWidth="10"
                  strokeDasharray={`${(totalScore / 100) * 264} 264`}
                  strokeLinecap="round"
                  className="transition-all duration-700"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-display font-bold text-white">{totalScore}</span>
                <span className="text-xs text-slate-500">/ 100</span>
              </div>
            </div>
            <span className={`badge px-3 py-1 text-sm font-semibold ${readiness.bg} ${readiness.color}`}>
              {readiness.label}
            </span>
          </div>

          {/* Eligible tiers */}
          <div className="card p-4 rounded-xl">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Target Companies</p>
            <div className="space-y-2">
              {companyTiers.map((tier) => {
                const eligible = totalScore >= tier.minScore;
                return (
                  <div key={tier.tier} className={`p-3 rounded-lg border ${eligible ? `${tier.bg} ${tier.border}` : 'bg-slate-900 border-slate-800 opacity-40'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-xs font-bold ${eligible ? tier.color : 'text-slate-500'}`}>{tier.tier}</span>
                      {eligible ? <CheckCircle2 size={12} className={tier.color} /> : <AlertCircle size={12} className="text-slate-600" />}
                    </div>
                    <p className="text-xs text-slate-500">{tier.package}</p>
                    <p className="text-xs text-slate-600 mt-0.5">{tier.companies.slice(0, 3).join(', ')}...</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Strengths / Weaknesses */}
          {evaluated && (
            <>
              {strengths.length > 0 && (
                <div className="card p-4 rounded-xl animate-slide-up">
                  <p className="text-xs font-semibold text-emerald-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <Star size={11} /> Strengths
                  </p>
                  <ul className="space-y-1">
                    {strengths.map((s) => (
                      <li key={s} className="text-xs text-slate-300 flex items-center gap-2">
                        <CheckCircle2 size={11} className="text-emerald-400 flex-shrink-0" />
                        {s}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {weaknesses.length > 0 && (
                <div className="card p-4 rounded-xl animate-slide-up">
                  <p className="text-xs font-semibold text-rose-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                    <TrendingUp size={11} /> Areas to Improve
                  </p>
                  <ul className="space-y-1">
                    {weaknesses.map((w) => (
                      <li key={w} className="text-xs text-slate-300 flex items-center gap-2">
                        <AlertCircle size={11} className="text-rose-400 flex-shrink-0" />
                        {w}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {/* Action plan */}
          {evaluated && totalScore < 80 && (
            <div className="card p-4 rounded-xl animate-slide-up">
              <p className="text-xs font-semibold text-blue-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Building2 size={11} /> 90-Day Action Plan
              </p>
              <div className="space-y-2">
                {[
                  { month: 'Month 1', task: 'DSA + Aptitude foundation' },
                  { month: 'Month 2', task: 'Projects + Resume building' },
                  { month: 'Month 3', task: 'Mock interviews + Applications' },
                ].map((item) => (
                  <div key={item.month} className="flex items-start gap-2">
                    <span className="badge bg-blue-500/10 text-blue-400 text-xs flex-shrink-0">{item.month}</span>
                    <span className="text-xs text-slate-400">{item.task}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
