import { useState, useEffect } from 'react';
import { Save, Plus, X, User, GraduationCap, Code2, Target, Briefcase } from 'lucide-react';
import { supabase, StudentProfile } from '../lib/supabase';

const DEPARTMENTS = [
  'Computer Science & Engineering', 'Information Technology', 'Electronics & Communication',
  'Electrical Engineering', 'Mechanical Engineering', 'Civil Engineering',
  'Chemical Engineering', 'Biotechnology', 'Data Science', 'Artificial Intelligence',
];

const COMMON_SKILLS = [
  'Python', 'Java', 'C++', 'JavaScript', 'React', 'Node.js', 'SQL', 'MySQL',
  'MongoDB', 'Docker', 'Git', 'AWS', 'Machine Learning', 'Deep Learning',
  'Data Structures', 'System Design', 'Linux', 'REST APIs',
];

const COMMON_INTERESTS = [
  'Web Development', 'Mobile Apps', 'Data Science', 'Machine Learning', 'Cloud Computing',
  'Cybersecurity', 'DevOps', 'Blockchain', 'Game Development', 'Open Source',
];

export default function StudentProfilePage() {
  const [profile, setProfile] = useState<StudentProfile | null>(null);
  const [form, setForm] = useState({
    name: '', department: '', year_of_study: 2, cgpa: 7.0,
    skills: [] as string[], interests: [] as string[],
    certifications: [] as string[], career_goals: '',
    internship_experience: '', projects: [] as string[],
  });
  const [saved, setSaved] = useState(false);
  const [skillInput, setSkillInput] = useState('');
  const [certInput, setCertInput] = useState('');
  const [projectInput, setProjectInput] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadProfile(); }, []);

  async function loadProfile() {
    const { data } = await supabase.from('student_profiles').select('*').limit(1).maybeSingle();
    if (data) {
      setProfile(data);
      setForm({
        name: data.name, department: data.department, year_of_study: data.year_of_study,
        cgpa: data.cgpa, skills: data.skills, interests: data.interests,
        certifications: data.certifications, career_goals: data.career_goals,
        internship_experience: data.internship_experience, projects: data.projects,
      });
    }
    setLoading(false);
  }

  async function saveProfile() {
    if (profile) {
      await supabase.from('student_profiles').update({ ...form, updated_at: new Date().toISOString() }).eq('id', profile.id);
    } else {
      const { data } = await supabase.from('student_profiles').insert(form).select().maybeSingle();
      if (data) setProfile(data);
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  function addTag(list: string[], item: string, setter: (v: string[]) => void, inputSetter: (v: string) => void) {
    if (item.trim() && !list.includes(item.trim())) {
      setter([...list, item.trim()]);
      inputSetter('');
    }
  }

  function removeTag(list: string[], item: string, setter: (v: string[]) => void) {
    setter(list.filter((i) => i !== item));
  }

  if (loading) {
    return <div className="flex-1 flex items-center justify-center"><p className="text-slate-500 animate-pulse-subtle">Loading profile...</p></div>;
  }

  const completeness = [
    form.name, form.department, form.career_goals,
    form.skills.length > 0, form.projects.length > 0, form.certifications.length > 0,
  ].filter(Boolean).length;
  const completenessPercent = Math.round((completeness / 6) * 100);

  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-3xl mx-auto w-full">
      {/* Profile header */}
      <div className="card p-5 rounded-2xl mb-6 flex items-center gap-5">
        <div className="w-16 h-16 rounded-2xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center flex-shrink-0">
          <User size={28} className="text-blue-400" />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="font-display font-bold text-white text-xl">{form.name || 'Your Name'}</h2>
          <p className="text-slate-400 text-sm">{form.department || 'Department'} · Year {form.year_of_study}</p>
          <div className="flex items-center gap-2 mt-2">
            <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden max-w-32">
              <div className="h-full bg-blue-500 rounded-full transition-all duration-500" style={{ width: `${completenessPercent}%` }} />
            </div>
            <span className="text-xs text-slate-500">{completenessPercent}% complete</span>
          </div>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="text-3xl font-display font-bold text-white">{form.cgpa}</p>
          <p className="text-xs text-slate-500">CGPA</p>
        </div>
      </div>

      <div className="space-y-5">
        {/* Basic Info */}
        <div className="card p-5 rounded-xl">
          <div className="flex items-center gap-2 mb-4">
            <GraduationCap size={15} className="text-blue-400" />
            <h3 className="font-semibold text-white text-sm">Basic Information</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Full Name</label>
              <input
                type="text" value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Rahul Sharma"
                className="input-field w-full text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Department</label>
              <select
                value={form.department}
                onChange={(e) => setForm({ ...form, department: e.target.value })}
                className="input-field w-full text-sm"
              >
                <option value="">Select department...</option>
                {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Year of Study</label>
              <select
                value={form.year_of_study}
                onChange={(e) => setForm({ ...form, year_of_study: parseInt(e.target.value) })}
                className="input-field w-full text-sm"
              >
                {[1, 2, 3, 4].map((y) => <option key={y} value={y}>Year {y}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">CGPA</label>
              <input
                type="number" min={0} max={10} step={0.01}
                value={form.cgpa}
                onChange={(e) => setForm({ ...form, cgpa: parseFloat(e.target.value) || 0 })}
                className="input-field w-full text-sm"
              />
            </div>
          </div>
        </div>

        {/* Skills */}
        <div className="card p-5 rounded-xl">
          <div className="flex items-center gap-2 mb-4">
            <Code2 size={15} className="text-emerald-400" />
            <h3 className="font-semibold text-white text-sm">Technical Skills</h3>
          </div>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {form.skills.map((skill) => (
              <span key={skill} className="badge bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 group">
                {skill}
                <button onClick={() => removeTag(form.skills, skill, (v) => setForm({ ...form, skills: v }))} className="ml-1 hover:text-white">
                  <X size={10} />
                </button>
              </span>
            ))}
          </div>
          <div className="flex gap-2 mb-3">
            <input
              type="text" value={skillInput}
              onChange={(e) => setSkillInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && addTag(form.skills, skillInput, (v) => setForm({ ...form, skills: v }), setSkillInput)}
              placeholder="Add skill and press Enter"
              className="input-field flex-1 text-sm"
            />
            <button onClick={() => addTag(form.skills, skillInput, (v) => setForm({ ...form, skills: v }), setSkillInput)} className="btn-secondary px-3 py-2">
              <Plus size={14} />
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {COMMON_SKILLS.filter((s) => !form.skills.includes(s)).slice(0, 8).map((s) => (
              <button
                key={s}
                onClick={() => setForm({ ...form, skills: [...form.skills, s] })}
                className="badge bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700 hover:border-slate-500 cursor-pointer transition-colors text-xs"
              >
                + {s}
              </button>
            ))}
          </div>
        </div>

        {/* Interests */}
        <div className="card p-5 rounded-xl">
          <div className="flex items-center gap-2 mb-4">
            <Target size={15} className="text-amber-400" />
            <h3 className="font-semibold text-white text-sm">Interests & Career Goals</h3>
          </div>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {form.interests.map((interest) => (
              <span key={interest} className="badge bg-amber-500/10 text-amber-300 border border-amber-500/20">
                {interest}
                <button onClick={() => removeTag(form.interests, interest, (v) => setForm({ ...form, interests: v }))} className="ml-1 hover:text-white">
                  <X size={10} />
                </button>
              </span>
            ))}
          </div>
          <div className="flex flex-wrap gap-1.5 mb-4">
            {COMMON_INTERESTS.filter((i) => !form.interests.includes(i)).map((i) => (
              <button
                key={i}
                onClick={() => setForm({ ...form, interests: [...form.interests, i] })}
                className="badge bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700 hover:border-slate-500 cursor-pointer transition-colors text-xs"
              >
                + {i}
              </button>
            ))}
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">Career Goals</label>
            <textarea
              value={form.career_goals}
              onChange={(e) => setForm({ ...form, career_goals: e.target.value })}
              placeholder="e.g. Become a Full Stack Developer at a product company, work on AI-powered applications..."
              rows={3}
              className="input-field w-full text-sm resize-none"
            />
          </div>
        </div>

        {/* Experience & Certifications */}
        <div className="card p-5 rounded-xl">
          <div className="flex items-center gap-2 mb-4">
            <Briefcase size={15} className="text-purple-400" />
            <h3 className="font-semibold text-white text-sm">Experience & Certifications</h3>
          </div>
          <div className="space-y-4">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Internship Experience</label>
              <textarea
                value={form.internship_experience}
                onChange={(e) => setForm({ ...form, internship_experience: e.target.value })}
                placeholder="e.g. Software Development Intern at XYZ Company (Summer 2024) — worked on React.js frontend..."
                rows={3}
                className="input-field w-full text-sm resize-none"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Certifications</label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {form.certifications.map((cert) => (
                  <span key={cert} className="badge bg-purple-500/10 text-purple-300 border border-purple-500/20">
                    {cert}
                    <button onClick={() => removeTag(form.certifications, cert, (v) => setForm({ ...form, certifications: v }))} className="ml-1 hover:text-white">
                      <X size={10} />
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text" value={certInput}
                  onChange={(e) => setCertInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addTag(form.certifications, certInput, (v) => setForm({ ...form, certifications: v }), setCertInput)}
                  placeholder="Add certification and press Enter"
                  className="input-field flex-1 text-sm"
                />
                <button onClick={() => addTag(form.certifications, certInput, (v) => setForm({ ...form, certifications: v }), setCertInput)} className="btn-secondary px-3 py-2">
                  <Plus size={14} />
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Projects</label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {form.projects.map((proj) => (
                  <span key={proj} className="badge bg-blue-500/10 text-blue-300 border border-blue-500/20">
                    {proj}
                    <button onClick={() => removeTag(form.projects, proj, (v) => setForm({ ...form, projects: v }))} className="ml-1 hover:text-white">
                      <X size={10} />
                    </button>
                  </span>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  type="text" value={projectInput}
                  onChange={(e) => setProjectInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addTag(form.projects, projectInput, (v) => setForm({ ...form, projects: v }), setProjectInput)}
                  placeholder="Add project name and press Enter"
                  className="input-field flex-1 text-sm"
                />
                <button onClick={() => addTag(form.projects, projectInput, (v) => setForm({ ...form, projects: v }), setProjectInput)} className="btn-secondary px-3 py-2">
                  <Plus size={14} />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Save button */}
        <button
          onClick={saveProfile}
          className={`btn-primary w-full flex items-center justify-center gap-2 py-3 transition-all ${saved ? 'bg-emerald-600 hover:bg-emerald-600' : ''}`}
        >
          <Save size={15} />
          {saved ? 'Profile Saved!' : 'Save Profile'}
        </button>
      </div>
    </div>
  );
}
