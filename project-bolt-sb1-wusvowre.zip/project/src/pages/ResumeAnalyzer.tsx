import { useState } from 'react';
import { FileText, Upload, CheckCircle2, AlertTriangle, XCircle, Lightbulb } from 'lucide-react';

type Section = { name: string; present: boolean; quality: 'good' | 'weak' | 'missing' };
type Suggestion = { type: 'success' | 'warning' | 'error'; text: string };

function analyzeResume(text: string): {
  atsScore: number;
  qualityScore: number;
  sections: Section[];
  suggestions: Suggestion[];
  keywords: string[];
  missingKeywords: string[];
} {
  const lower = text.toLowerCase();
  const wordCount = text.split(/\s+/).length;

  const sectionChecks: Section[] = [
    { name: 'Contact Information', present: /phone|email|linkedin|github/.test(lower), quality: /phone|email|linkedin|github/.test(lower) ? 'good' : 'missing' },
    { name: 'Summary/Objective', present: /summary|objective|profile/.test(lower), quality: /summary|objective|profile/.test(lower) ? 'good' : 'missing' },
    { name: 'Education', present: /education|university|college|degree|b\.tech|b\.e/.test(lower), quality: /education|university|college|degree|b\.tech|b\.e/.test(lower) ? 'good' : 'missing' },
    { name: 'Skills', present: /skills|technologies|tools/.test(lower), quality: /skills|technologies|tools/.test(lower) ? 'good' : 'missing' },
    { name: 'Projects', present: /project/.test(lower), quality: /project/.test(lower) ? 'good' : 'missing' },
    { name: 'Experience/Internship', present: /experience|intern|internship|work/.test(lower), quality: /experience|intern|internship|work/.test(lower) ? 'good' : 'weak' },
    { name: 'Certifications', present: /certification|certified|certificate/.test(lower), quality: /certification|certified|certificate/.test(lower) ? 'good' : 'missing' },
    { name: 'Achievements', present: /achievement|award|honor|rank|prize/.test(lower), quality: /achievement|award|honor|rank|prize/.test(lower) ? 'good' : 'weak' },
  ];

  const techKeywords = ['python', 'java', 'javascript', 'react', 'node', 'sql', 'git', 'docker', 'aws', 'machine learning', 'data structures'];
  const foundKeywords = techKeywords.filter((k) => lower.includes(k));
  const missingKeywords = techKeywords.filter((k) => !lower.includes(k)).slice(0, 4);

  const presentSections = sectionChecks.filter((s) => s.present).length;
  const atsScore = Math.min(
    95,
    Math.round(
      (presentSections / sectionChecks.length) * 50 +
      (foundKeywords.length / techKeywords.length) * 30 +
      (wordCount > 200 ? 10 : wordCount / 20) +
      (wordCount < 1000 ? 10 : 5)
    )
  );

  const qualityScore = Math.min(
    98,
    Math.round(
      atsScore * 0.6 +
      (text.includes('%') || text.includes('increased') || text.includes('reduced') ? 15 : 5) +
      (sectionChecks.filter((s) => s.quality === 'good').length / sectionChecks.length) * 25
    )
  );

  const suggestions: Suggestion[] = [];
  if (wordCount < 150) suggestions.push({ type: 'error', text: 'Resume is too short. Aim for 400–700 words.' });
  if (wordCount > 800) suggestions.push({ type: 'warning', text: 'Resume may be too long. Keep it to 1 page for freshers.' });
  if (!lower.includes('github')) suggestions.push({ type: 'warning', text: 'Add your GitHub profile link for better credibility.' });
  if (!lower.includes('linkedin')) suggestions.push({ type: 'warning', text: 'Include your LinkedIn URL in contact information.' });
  if (!text.includes('%') && !text.includes('increased') && !text.includes('reduced')) {
    suggestions.push({ type: 'warning', text: 'Quantify achievements with numbers and percentages (e.g., "Improved performance by 30%").' });
  }
  if (foundKeywords.length < 4) suggestions.push({ type: 'error', text: 'Add more technical keywords relevant to your target role.' });
  if (sectionChecks.filter((s) => s.quality === 'good').length >= 5) {
    suggestions.push({ type: 'success', text: 'Good section coverage! Your resume structure is well-organized.' });
  }
  if (lower.includes('responsible for')) {
    suggestions.push({ type: 'warning', text: 'Replace "responsible for" with strong action verbs like "developed", "built", "implemented".' });
  }

  return { atsScore, qualityScore, sections: sectionChecks, suggestions, keywords: foundKeywords, missingKeywords };
}

export default function ResumeAnalyzer() {
  const [resumeText, setResumeText] = useState('');
  const [result, setResult] = useState<ReturnType<typeof analyzeResume> | null>(null);
  const [analyzed, setAnalyzed] = useState(false);

  function analyze() {
    if (!resumeText.trim()) return;
    setResult(analyzeResume(resumeText));
    setAnalyzed(true);
  }

  const ScoreRing = ({ score, label, color }: { score: number; label: string; color: string }) => (
    <div className="flex flex-col items-center gap-2">
      <div className="relative w-24 h-24">
        <svg className="w-24 h-24 -rotate-90" viewBox="0 0 100 100">
          <circle cx="50" cy="50" r="40" fill="none" stroke="#1e293b" strokeWidth="10" />
          <circle
            cx="50" cy="50" r="40" fill="none" stroke={color}
            strokeWidth="10"
            strokeDasharray={`${(score / 100) * 251} 251`}
            strokeLinecap="round"
            className="transition-all duration-700"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-display font-bold text-white">{score}</span>
          <span className="text-xs text-slate-500">/ 100</span>
        </div>
      </div>
      <span className="text-xs text-slate-400 font-medium">{label}</span>
    </div>
  );

  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-5xl mx-auto w-full">
      <div className="mb-6">
        <h2 className="font-display font-bold text-white text-2xl mb-1">Resume Analyzer</h2>
        <p className="text-slate-500 text-sm">Paste your resume text to get ATS score, quality analysis, and improvement suggestions.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="flex flex-col gap-4">
          <div className="card rounded-xl overflow-hidden flex flex-col" style={{ minHeight: '400px' }}>
            <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-800">
              <FileText size={15} className="text-purple-400" />
              <span className="text-sm font-medium text-slate-300">Resume Content</span>
              <span className="ml-auto text-xs text-slate-500">{resumeText.split(/\s+/).filter(Boolean).length} words</span>
            </div>
            <textarea
              value={resumeText}
              onChange={(e) => { setResumeText(e.target.value); setAnalyzed(false); }}
              placeholder="Paste your resume text here...

Include sections like:
- Contact Information (Name, Email, Phone, LinkedIn, GitHub)
- Summary/Objective
- Education (Degree, University, CGPA)
- Technical Skills
- Projects (with tech stack and impact)
- Internship Experience
- Certifications
- Achievements"
              className="flex-1 bg-transparent text-slate-300 text-sm p-4 resize-none focus:outline-none placeholder-slate-600 leading-relaxed"
            />
          </div>
          <button
            onClick={analyze}
            disabled={!resumeText.trim()}
            className="btn-primary flex items-center justify-center gap-2 py-3"
          >
            <Upload size={15} />
            Analyze Resume
          </button>

          {/* Tips */}
          <div className="card p-4 rounded-xl">
            <div className="flex items-center gap-2 mb-3">
              <Lightbulb size={14} className="text-amber-400" />
              <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Quick Tips</span>
            </div>
            <ul className="space-y-1.5">
              {[
                'Use action verbs: Built, Developed, Implemented, Designed',
                'Quantify impact: "Improved load time by 40%"',
                'Keep to 1 page for freshers',
                'Match keywords from the job description',
                'Use consistent formatting throughout',
              ].map((tip) => (
                <li key={tip} className="text-xs text-slate-400 flex items-start gap-2">
                  <span className="text-amber-400 flex-shrink-0 mt-0.5">•</span>
                  {tip}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Results */}
        <div className="space-y-4">
          {analyzed && result ? (
            <>
              {/* Scores */}
              <div className="card p-6 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4 text-center">Analysis Scores</p>
                <div className="flex justify-around">
                  <ScoreRing score={result.atsScore} label="ATS Score" color="#8b5cf6" />
                  <ScoreRing score={result.qualityScore} label="Quality Score" color="#3b82f6" />
                </div>
              </div>

              {/* Sections */}
              <div className="card p-4 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Section Analysis</p>
                <div className="space-y-2">
                  {result.sections.map((section) => (
                    <div key={section.name} className="flex items-center justify-between">
                      <span className="text-sm text-slate-300">{section.name}</span>
                      <div className="flex items-center gap-1.5">
                        {section.quality === 'good' && <CheckCircle2 size={14} className="text-emerald-400" />}
                        {section.quality === 'weak' && <AlertTriangle size={14} className="text-amber-400" />}
                        {section.quality === 'missing' && <XCircle size={14} className="text-rose-400" />}
                        <span className={`text-xs ${section.quality === 'good' ? 'text-emerald-400' : section.quality === 'weak' ? 'text-amber-400' : 'text-rose-400'}`}>
                          {section.quality === 'good' ? 'Good' : section.quality === 'weak' ? 'Weak' : 'Missing'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Keywords */}
              <div className="card p-4 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Keyword Analysis</p>
                {result.keywords.length > 0 && (
                  <div className="mb-3">
                    <p className="text-xs text-emerald-400 mb-1.5">Found Keywords</p>
                    <div className="flex flex-wrap gap-1.5">
                      {result.keywords.map((k) => (
                        <span key={k} className="badge bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">{k}</span>
                      ))}
                    </div>
                  </div>
                )}
                {result.missingKeywords.length > 0 && (
                  <div>
                    <p className="text-xs text-rose-400 mb-1.5">Missing Keywords</p>
                    <div className="flex flex-wrap gap-1.5">
                      {result.missingKeywords.map((k) => (
                        <span key={k} className="badge bg-rose-500/10 text-rose-400 border border-rose-500/20">{k}</span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Suggestions */}
              <div className="card p-4 rounded-xl">
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Suggestions</p>
                <div className="space-y-2">
                  {result.suggestions.map((s, i) => (
                    <div key={i} className={`flex items-start gap-2.5 p-2.5 rounded-lg ${
                      s.type === 'success' ? 'bg-emerald-500/5' :
                      s.type === 'warning' ? 'bg-amber-500/5' : 'bg-rose-500/5'
                    }`}>
                      {s.type === 'success' && <CheckCircle2 size={13} className="text-emerald-400 mt-0.5 flex-shrink-0" />}
                      {s.type === 'warning' && <AlertTriangle size={13} className="text-amber-400 mt-0.5 flex-shrink-0" />}
                      {s.type === 'error' && <XCircle size={13} className="text-rose-400 mt-0.5 flex-shrink-0" />}
                      <span className="text-xs text-slate-300">{s.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-64 card rounded-xl">
              <FileText size={40} className="text-slate-700 mb-3" />
              <p className="text-slate-500 text-sm">Paste your resume and click Analyze</p>
              <p className="text-slate-600 text-xs mt-1">Get ATS score, quality analysis & suggestions</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
