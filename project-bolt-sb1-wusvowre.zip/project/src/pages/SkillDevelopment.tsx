import { useState } from 'react';
import { Zap, ExternalLink, Clock, Star, Filter } from 'lucide-react';

type Resource = {
  id: string;
  title: string;
  platform: string;
  category: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  duration: string;
  rating: number;
  free: boolean;
  url: string;
  description: string;
  skills: string[];
};

const resources: Resource[] = [
  {
    id: '1', title: 'Python for Everybody', platform: 'Coursera', category: 'Programming',
    level: 'Beginner', duration: '20 hours', rating: 4.8, free: false,
    url: 'https://www.coursera.org/specializations/python',
    description: 'Learn Python from scratch with hands-on projects. Perfect for beginners.',
    skills: ['Python', 'Programming', 'Data Structures'],
  },
  {
    id: '2', title: 'freeCodeCamp JavaScript', platform: 'freeCodeCamp', category: 'Web Development',
    level: 'Beginner', duration: '300 hours', rating: 4.7, free: true,
    url: 'https://www.freecodecamp.org',
    description: 'Complete web development curriculum covering HTML, CSS, JavaScript, and more.',
    skills: ['JavaScript', 'HTML', 'CSS', 'React'],
  },
  {
    id: '3', title: 'Machine Learning Specialization', platform: 'Coursera (Andrew Ng)', category: 'Data Science',
    level: 'Intermediate', duration: '45 hours', rating: 4.9, free: false,
    url: 'https://www.coursera.org/specializations/machine-learning-introduction',
    description: 'The gold standard for learning ML. Covers supervised, unsupervised, and deep learning.',
    skills: ['Machine Learning', 'Python', 'TensorFlow', 'Statistics'],
  },
  {
    id: '4', title: 'AWS Cloud Practitioner', platform: 'AWS Training', category: 'Cloud',
    level: 'Beginner', duration: '20 hours', rating: 4.6, free: true,
    url: 'https://aws.amazon.com/training',
    description: 'Official AWS certification prep. Covers core cloud concepts and AWS services.',
    skills: ['AWS', 'Cloud Computing', 'Architecture'],
  },
  {
    id: '5', title: 'React — The Complete Guide', platform: 'Udemy', category: 'Web Development',
    level: 'Intermediate', duration: '60 hours', rating: 4.8, free: false,
    url: 'https://www.udemy.com',
    description: 'Master React.js including hooks, Redux, and Next.js for modern web development.',
    skills: ['React', 'JavaScript', 'Redux', 'Next.js'],
  },
  {
    id: '6', title: 'Google Data Analytics Certificate', platform: 'Coursera', category: 'Data Science',
    level: 'Beginner', duration: '180 hours', rating: 4.8, free: false,
    url: 'https://www.coursera.org/professional-certificates/google-data-analytics',
    description: 'Industry-recognized certification covering data analysis, visualization, and SQL.',
    skills: ['SQL', 'Tableau', 'R', 'Data Analysis'],
  },
  {
    id: '7', title: 'CS50 — Introduction to Computer Science', platform: 'edX (Harvard)', category: 'CS Fundamentals',
    level: 'Beginner', duration: '100 hours', rating: 4.9, free: true,
    url: 'https://cs50.harvard.edu',
    description: 'Harvard\'s legendary intro to CS. Covers algorithms, data structures, and web development.',
    skills: ['C', 'Python', 'Algorithms', 'Data Structures'],
  },
  {
    id: '8', title: 'System Design Interview Course', platform: 'Educative', category: 'System Design',
    level: 'Advanced', duration: '40 hours', rating: 4.7, free: false,
    url: 'https://www.educative.io',
    description: 'Prepare for system design interviews at FAANG companies with practical examples.',
    skills: ['System Design', 'Scalability', 'Distributed Systems'],
  },
];

const projectIdeas: { domain: string; difficulty: string; title: string; tech: string; impact: string }[] = [
  { domain: 'Web Dev', difficulty: 'Beginner', title: 'Personal Portfolio Website', tech: 'HTML, CSS, JavaScript', impact: 'Showcases your work to recruiters' },
  { domain: 'Web Dev', difficulty: 'Intermediate', title: 'Full Stack Task Manager', tech: 'React, Node.js, MongoDB', impact: 'Demonstrates full stack capability' },
  { domain: 'Data Science', difficulty: 'Beginner', title: 'Movie Recommendation System', tech: 'Python, Pandas, Scikit-learn', impact: 'Entry-level ML project' },
  { domain: 'Data Science', difficulty: 'Intermediate', title: 'Stock Price Predictor', tech: 'Python, LSTM, TensorFlow', impact: 'Shows deep learning skills' },
  { domain: 'Mobile App', difficulty: 'Beginner', title: 'Expense Tracker App', tech: 'React Native / Flutter', impact: 'Practical app development experience' },
  { domain: 'DevOps', difficulty: 'Intermediate', title: 'CI/CD Pipeline Setup', tech: 'GitHub Actions, Docker, AWS', impact: 'Shows DevOps proficiency' },
];

const categories = ['All', 'Programming', 'Web Development', 'Data Science', 'Cloud', 'CS Fundamentals', 'System Design'];
const levels = ['All', 'Beginner', 'Intermediate', 'Advanced'];

const levelColors: Record<string, string> = {
  Beginner: 'text-emerald-400 bg-emerald-500/10',
  Intermediate: 'text-blue-400 bg-blue-500/10',
  Advanced: 'text-rose-400 bg-rose-500/10',
};

export default function SkillDevelopment() {
  const [category, setCategory] = useState('All');
  const [level, setLevel] = useState('All');
  const [freeOnly, setFreeOnly] = useState(false);
  const [tab, setTab] = useState<'courses' | 'projects'>('courses');

  const filtered = resources.filter((r) => {
    if (category !== 'All' && r.category !== category) return false;
    if (level !== 'All' && r.level !== level) return false;
    if (freeOnly && !r.free) return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <div className="flex gap-1 bg-slate-800 rounded-lg p-1">
            {(['courses', 'projects'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors capitalize ${
                  tab === t ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {t === 'courses' ? 'Courses & Certifications' : 'Project Ideas'}
              </button>
            ))}
          </div>
        </div>

        {tab === 'courses' ? (
          <>
            {/* Filters */}
            <div className="flex flex-wrap gap-3 mb-5 items-center">
              <div className="flex items-center gap-1.5">
                <Filter size={13} className="text-slate-500" />
                <span className="text-xs text-slate-500">Filter:</span>
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${category === cat ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <div className="flex gap-1.5">
                {levels.map((l) => (
                  <button
                    key={l}
                    onClick={() => setLevel(l)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${level === l ? 'bg-slate-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-slate-200'}`}
                  >
                    {l}
                  </button>
                ))}
              </div>
              <label className="flex items-center gap-2 cursor-pointer ml-auto">
                <div
                  onClick={() => setFreeOnly(!freeOnly)}
                  className={`w-8 h-4 rounded-full transition-colors relative ${freeOnly ? 'bg-blue-600' : 'bg-slate-700'}`}
                >
                  <div className={`w-3 h-3 rounded-full bg-white absolute top-0.5 transition-all ${freeOnly ? 'left-4' : 'left-0.5'}`} />
                </div>
                <span className="text-xs text-slate-400">Free only</span>
              </label>
            </div>

            {/* Resource grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filtered.map((resource) => (
                <div key={resource.id} className="card p-5 rounded-xl hover:bg-slate-800/50 transition-colors group animate-fade-in">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-slate-200 text-sm group-hover:text-white transition-colors">{resource.title}</h3>
                      <p className="text-xs text-slate-500 mt-0.5">{resource.platform}</p>
                    </div>
                    <a
                      href={resource.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-500 hover:text-blue-400 transition-colors flex-shrink-0"
                    >
                      <ExternalLink size={13} />
                    </a>
                  </div>
                  <p className="text-xs text-slate-400 mb-3 leading-relaxed">{resource.description}</p>
                  <div className="flex items-center gap-2 mb-3 flex-wrap">
                    <span className={`badge ${levelColors[resource.level]} text-xs`}>{resource.level}</span>
                    <span className={`badge text-xs ${resource.free ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                      {resource.free ? 'Free' : 'Paid'}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-slate-500">
                      <Clock size={10} /> {resource.duration}
                    </span>
                    <span className="flex items-center gap-1 text-xs text-amber-400 ml-auto">
                      <Star size={10} fill="currentColor" /> {resource.rating}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {resource.skills.map((skill) => (
                      <span key={skill} className="badge bg-slate-800 text-slate-400 border border-slate-700 text-xs">{skill}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            {filtered.length === 0 && (
              <div className="text-center py-12">
                <Zap size={32} className="text-slate-700 mx-auto mb-3" />
                <p className="text-slate-500">No courses match your filters.</p>
              </div>
            )}
          </>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {projectIdeas.map((project) => (
              <div key={project.title} className="card p-5 rounded-xl hover:bg-slate-800/50 transition-colors animate-fade-in">
                <div className="flex items-center justify-between mb-3">
                  <span className="badge bg-slate-800 text-slate-400 border border-slate-700 text-xs">{project.domain}</span>
                  <span className={`badge text-xs ${project.difficulty === 'Beginner' ? 'text-emerald-400 bg-emerald-500/10' : 'text-blue-400 bg-blue-500/10'}`}>
                    {project.difficulty}
                  </span>
                </div>
                <h3 className="font-semibold text-slate-200 text-sm mb-2">{project.title}</h3>
                <p className="text-xs text-slate-500 mb-3">
                  <span className="text-slate-400 font-medium">Tech: </span>{project.tech}
                </p>
                <div className="flex items-start gap-1.5 p-2.5 rounded-lg bg-emerald-500/5 border border-emerald-500/10">
                  <Zap size={11} className="text-emerald-400 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-emerald-300">{project.impact}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
