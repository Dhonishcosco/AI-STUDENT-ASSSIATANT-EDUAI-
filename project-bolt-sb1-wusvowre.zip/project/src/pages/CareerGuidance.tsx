import { useState } from 'react';
import { Briefcase, TrendingUp, BookOpen, Award, ExternalLink, ChevronDown, ChevronUp } from 'lucide-react';

type CareerPath = {
  id: string;
  title: string;
  demand: 'Very High' | 'High' | 'Growing';
  package: string;
  description: string;
  requiredSkills: string[];
  roadmap: { phase: string; duration: string; tasks: string[] }[];
  certifications: string[];
  companies: string[];
  color: string;
  bg: string;
};

const careerPaths: CareerPath[] = [
  {
    id: 'sde',
    title: 'Software Development Engineer',
    demand: 'Very High', package: '8–50 LPA',
    description: 'Build scalable software systems and applications. Most sought-after role in the IT industry.',
    requiredSkills: ['DSA', 'System Design', 'OOP', 'Git', 'SQL'],
    roadmap: [
      { phase: 'Foundation', duration: '3 months', tasks: ['Master one language (Python/Java)', 'Learn DSA fundamentals', 'Build 2 projects'] },
      { phase: 'Core Skills', duration: '3 months', tasks: ['System design basics', 'Database design', 'REST APIs', 'Git workflow'] },
      { phase: 'Specialization', duration: '3 months', tasks: ['Choose: Backend/Frontend/Full-Stack', 'Build portfolio project', 'Open source contributions'] },
      { phase: 'Placement Prep', duration: '2 months', tasks: ['LeetCode 100+ problems', 'Mock interviews', 'Resume optimization'] },
    ],
    certifications: ['AWS Developer', 'Oracle Java SE', 'Google Associate Android Developer'],
    companies: ['Google', 'Microsoft', 'Amazon', 'Flipkart', 'Zomato'],
    color: 'text-blue-400', bg: 'bg-blue-500/10',
  },
  {
    id: 'ds',
    title: 'Data Scientist / ML Engineer',
    demand: 'High', package: '8–30 LPA',
    description: 'Extract insights from data and build machine learning models for business intelligence.',
    requiredSkills: ['Python', 'Statistics', 'SQL', 'Machine Learning', 'Data Visualization'],
    roadmap: [
      { phase: 'Data Basics', duration: '2 months', tasks: ['Python + NumPy + Pandas', 'SQL for analytics', 'Statistics fundamentals'] },
      { phase: 'ML Core', duration: '3 months', tasks: ['Scikit-learn', 'Supervised & Unsupervised learning', 'Model evaluation'] },
      { phase: 'Deep Learning', duration: '3 months', tasks: ['TensorFlow/PyTorch', 'Neural networks', 'NLP/Computer Vision basics'] },
      { phase: 'Projects', duration: '2 months', tasks: ['End-to-end ML projects', 'Kaggle competitions', 'Deploy models'] },
    ],
    certifications: ['Google Data Analytics', 'IBM Data Science', 'Coursera ML Specialization'],
    companies: ['Uber', 'Swiggy', 'PhonePe', 'CRED', 'MakeMyTrip'],
    color: 'text-purple-400', bg: 'bg-purple-500/10',
  },
  {
    id: 'cloud',
    title: 'Cloud / DevOps Engineer',
    demand: 'Very High', package: '10–35 LPA',
    description: 'Design, deploy, and manage cloud infrastructure and CI/CD pipelines.',
    requiredSkills: ['Linux', 'Docker', 'Kubernetes', 'AWS/GCP/Azure', 'CI/CD'],
    roadmap: [
      { phase: 'Linux & Networking', duration: '1.5 months', tasks: ['Linux fundamentals', 'Networking basics', 'Shell scripting'] },
      { phase: 'Cloud Basics', duration: '2 months', tasks: ['AWS/GCP core services', 'IAM, S3, EC2', 'Cloud architecture patterns'] },
      { phase: 'DevOps Tools', duration: '3 months', tasks: ['Docker & Kubernetes', 'Jenkins/GitHub Actions', 'Terraform/Ansible'] },
      { phase: 'Certifications', duration: '2 months', tasks: ['AWS certifications', 'Kubernetes CKAD', 'Build DevOps portfolio'] },
    ],
    certifications: ['AWS Solutions Architect', 'Google Cloud Associate', 'CKA/CKAD', 'Azure Administrator'],
    companies: ['Razorpay', 'PayU', 'Freshworks', 'MuSigma', 'TCS Digital'],
    color: 'text-amber-400', bg: 'bg-amber-500/10',
  },
  {
    id: 'security',
    title: 'Cybersecurity Engineer',
    demand: 'Growing', package: '8–25 LPA',
    description: 'Protect systems, networks, and applications from digital threats and vulnerabilities.',
    requiredSkills: ['Networking', 'Linux', 'Python', 'Ethical Hacking', 'Cryptography'],
    roadmap: [
      { phase: 'Foundations', duration: '2 months', tasks: ['Networking fundamentals', 'Linux security', 'Security concepts'] },
      { phase: 'Security Tools', duration: '2 months', tasks: ['Wireshark, Nmap', 'Metasploit basics', 'OWASP Top 10'] },
      { phase: 'Specialization', duration: '3 months', tasks: ['Penetration testing', 'Web application security', 'CTF challenges'] },
      { phase: 'Certifications', duration: '2 months', tasks: ['CompTIA Security+', 'CEH preparation', 'Bug bounty hunting'] },
    ],
    certifications: ['CompTIA Security+', 'CEH (Certified Ethical Hacker)', 'OSCP'],
    companies: ['Wipro CyberSecurity', 'IBM Security', 'Accenture', 'Deloitte'],
    color: 'text-rose-400', bg: 'bg-rose-500/10',
  },
];

const demandColors: Record<string, string> = {
  'Very High': 'text-emerald-400 bg-emerald-500/10',
  'High': 'text-blue-400 bg-blue-500/10',
  'Growing': 'text-amber-400 bg-amber-500/10',
};

export default function CareerGuidance() {
  const [selected, setSelected] = useState<CareerPath>(careerPaths[0]);
  const [expandedPhase, setExpandedPhase] = useState<string | null>('Foundation');

  return (
    <div className="flex flex-1 min-h-0">
      {/* Career list */}
      <div className="w-64 flex-shrink-0 border-r border-slate-800 flex flex-col p-3 gap-2 overflow-y-auto">
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-2 mb-1">Career Paths</p>
        {careerPaths.map((path) => (
          <button
            key={path.id}
            onClick={() => setSelected(path)}
            className={`text-left p-3 rounded-xl transition-all ${
              selected.id === path.id ? `${path.bg} border border-${path.color.split('-')[1]}-500/20` : 'hover:bg-slate-800/60 border border-transparent'
            }`}
          >
            <p className={`text-sm font-medium ${selected.id === path.id ? path.color : 'text-slate-300'}`}>{path.title}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className={`badge ${demandColors[path.demand]} text-xs`}>{path.demand}</span>
              <span className="text-xs text-slate-600">{path.package}</span>
            </div>
          </button>
        ))}
      </div>

      {/* Career detail */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg ${selected.bg} mb-4`}>
          <Briefcase size={14} className={selected.color} />
          <span className={`text-sm font-semibold ${selected.color}`}>{selected.title}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
          <div className="lg:col-span-2 card p-5 rounded-xl">
            <p className="text-slate-300 text-sm leading-relaxed mb-4">{selected.description}</p>
            <div className="flex items-center gap-4">
              <div>
                <p className="text-xs text-slate-500">Average Package</p>
                <p className="text-lg font-display font-bold text-white">{selected.package}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500">Market Demand</p>
                <span className={`badge ${demandColors[selected.demand]}`}>{selected.demand}</span>
              </div>
            </div>
          </div>
          <div className="card p-5 rounded-xl">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Required Skills</p>
            <div className="flex flex-wrap gap-1.5">
              {selected.requiredSkills.map((skill) => (
                <span key={skill} className={`badge border ${selected.bg} ${selected.color}`}>{skill}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Roadmap */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp size={15} className={selected.color} />
            <h3 className="font-semibold text-white text-sm">Learning Roadmap</h3>
          </div>
          <div className="space-y-2">
            {selected.roadmap.map((phase, i) => (
              <div key={phase.phase} className="card rounded-xl overflow-hidden">
                <button
                  onClick={() => setExpandedPhase(expandedPhase === phase.phase ? null : phase.phase)}
                  className="w-full flex items-center justify-between p-4 text-left hover:bg-slate-800/30 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full ${selected.bg} flex items-center justify-center flex-shrink-0`}>
                      <span className={`text-xs font-bold ${selected.color}`}>{i + 1}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-200">{phase.phase}</p>
                      <p className="text-xs text-slate-500">{phase.duration}</p>
                    </div>
                  </div>
                  {expandedPhase === phase.phase ? <ChevronUp size={15} className="text-slate-500" /> : <ChevronDown size={15} className="text-slate-500" />}
                </button>
                {expandedPhase === phase.phase && (
                  <div className="px-4 pb-4 animate-fade-in">
                    <ul className="space-y-1.5">
                      {phase.tasks.map((task) => (
                        <li key={task} className="flex items-center gap-2 text-sm text-slate-300">
                          <div className={`w-1.5 h-1.5 rounded-full ${selected.bg} ${selected.color} flex-shrink-0`} style={{ background: 'currentColor' }} />
                          {task}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Certifications & Companies */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="card p-5 rounded-xl">
            <div className="flex items-center gap-2 mb-3">
              <Award size={14} className="text-amber-400" />
              <h3 className="font-semibold text-white text-sm">Recommended Certifications</h3>
            </div>
            <ul className="space-y-2">
              {selected.certifications.map((cert) => (
                <li key={cert} className="flex items-center gap-2 text-sm text-slate-300">
                  <div className="w-1.5 h-1.5 rounded-full bg-amber-400 flex-shrink-0" />
                  {cert}
                </li>
              ))}
            </ul>
          </div>
          <div className="card p-5 rounded-xl">
            <div className="flex items-center gap-2 mb-3">
              <BookOpen size={14} className="text-emerald-400" />
              <h3 className="font-semibold text-white text-sm">Top Hiring Companies</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              {selected.companies.map((company) => (
                <span key={company} className="badge bg-slate-800 text-slate-300 border border-slate-700">{company}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
