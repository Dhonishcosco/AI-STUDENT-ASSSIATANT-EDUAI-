import { useState, useEffect, useRef, useCallback } from 'react';
import { Send, Plus, Trash2, MessageSquare } from 'lucide-react';
import { supabase, ChatSession, ChatMessage as ChatMessageType } from '../lib/supabase';
import { generateResponse, AIMode } from '../lib/aiEngine';
import ChatMessage, { TypingIndicator } from '../components/ChatMessage';

type Props = {
  mode: AIMode;
};

export default function ChatAssistant({ mode }: Props) {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessageType[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  useEffect(() => {
    loadSessions();
  }, [mode]);

  useEffect(() => {
    if (activeSessionId) loadMessages(activeSessionId);
  }, [activeSessionId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping, scrollToBottom]);

  async function loadSessions() {
    const { data } = await supabase
      .from('chat_sessions')
      .select('*')
      .eq('mode', mode)
      .order('updated_at', { ascending: false })
      .limit(20);

    if (data && data.length > 0) {
      setSessions(data);
      setActiveSessionId(data[0].id);
    } else {
      await createSession();
    }
  }

  async function createSession() {
    const { data } = await supabase
      .from('chat_sessions')
      .insert({ mode, title: 'New Conversation' })
      .select()
      .maybeSingle();

    if (data) {
      setSessions((prev) => [data, ...prev]);
      setActiveSessionId(data.id);
      setMessages([]);
    }
  }

  async function loadMessages(sessionId: string) {
    setLoadingMsgs(true);
    const { data } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('session_id', sessionId)
      .order('created_at', { ascending: true });

    setMessages(data || []);
    setLoadingMsgs(false);

    if (!data || data.length === 0) {
      await sendWelcomeMessage(sessionId);
    }
  }

  async function sendWelcomeMessage(sessionId: string) {
    const welcomeContent = await generateResponse('hello', mode, []);
    const { data } = await supabase
      .from('chat_messages')
      .insert({ session_id: sessionId, role: 'assistant', content: welcomeContent })
      .select()
      .maybeSingle();

    if (data) setMessages([data]);
  }

  async function deleteSession(sessionId: string) {
    await supabase.from('chat_sessions').delete().eq('id', sessionId);
    setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    if (activeSessionId === sessionId) {
      const remaining = sessions.filter((s) => s.id !== sessionId);
      if (remaining.length > 0) {
        setActiveSessionId(remaining[0].id);
      } else {
        await createSession();
      }
    }
  }

  async function sendMessage() {
    if (!input.trim() || !activeSessionId || isTyping) return;
    const userText = input.trim();
    setInput('');

    const { data: userMsg } = await supabase
      .from('chat_messages')
      .insert({ session_id: activeSessionId, role: 'user', content: userText })
      .select()
      .maybeSingle();

    if (userMsg) setMessages((prev) => [...prev, userMsg]);

    await supabase
      .from('chat_sessions')
      .update({ title: userText.slice(0, 50), updated_at: new Date().toISOString() })
      .eq('id', activeSessionId);

    setSessions((prev) =>
      prev.map((s) => (s.id === activeSessionId ? { ...s, title: userText.slice(0, 50) } : s))
    );

    setIsTyping(true);
    const history = [...messages, userMsg].filter(Boolean).map((m) => ({
      role: m!.role,
      content: m!.content,
    }));

    const response = await generateResponse(userText, mode, history);
    setIsTyping(false);

    const { data: aiMsg } = await supabase
      .from('chat_messages')
      .insert({ session_id: activeSessionId, role: 'assistant', content: response })
      .select()
      .maybeSingle();

    if (aiMsg) setMessages((prev) => [...prev, aiMsg]);
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
  };

  return (
    <div className="flex flex-1 min-h-0">
      {/* Session sidebar */}
      <div className="w-56 flex-shrink-0 border-r border-slate-800 flex flex-col bg-slate-950/50">
        <div className="p-3 border-b border-slate-800">
          <button onClick={createSession} className="btn-primary w-full flex items-center justify-center gap-2 py-2 text-sm">
            <Plus size={15} />
            New Chat
          </button>
        </div>
        <div className="flex-1 overflow-y-auto py-2 space-y-0.5 px-2 scrollbar-hide">
          {sessions.map((session) => (
            <div
              key={session.id}
              className={`group flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-colors ${
                activeSessionId === session.id
                  ? 'bg-blue-600/15 text-white'
                  : 'text-slate-400 hover:bg-slate-800/60 hover:text-slate-200'
              }`}
              onClick={() => setActiveSessionId(session.id)}
            >
              <MessageSquare size={13} className="flex-shrink-0 opacity-60" />
              <span className="text-xs truncate flex-1">{session.title}</span>
              <button
                onClick={(e) => { e.stopPropagation(); deleteSession(session.id); }}
                className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-rose-400 transition-all flex-shrink-0"
              >
                <Trash2 size={12} />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {loadingMsgs ? (
            <div className="flex items-center justify-center h-full">
              <div className="animate-pulse-subtle text-slate-500 text-sm">Loading conversation...</div>
            </div>
          ) : (
            <>
              {messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
              ))}
              {isTyping && <TypingIndicator />}
              <div ref={bottomRef} />
            </>
          )}
        </div>

        {/* Input area */}
        <div className="flex-shrink-0 px-6 py-4 border-t border-slate-800 bg-slate-950/30">
          <div className="flex items-end gap-3 bg-slate-800/60 border border-slate-700 rounded-xl px-4 py-3 focus-within:border-blue-500/50 focus-within:ring-1 focus-within:ring-blue-500/20 transition-all">
            <textarea
              ref={inputRef}
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Ask me anything... (Shift+Enter for new line)"
              rows={1}
              className="flex-1 bg-transparent text-slate-100 text-sm placeholder-slate-500 resize-none focus:outline-none leading-relaxed"
              style={{ maxHeight: '120px' }}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || isTyping}
              className="w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-500 flex items-center justify-center transition-all active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
            >
              <Send size={14} className="text-white" />
            </button>
          </div>
          <p className="text-xs text-slate-600 text-center mt-2">
            EDUAI can make mistakes. Verify important information independently.
          </p>
        </div>
      </div>
    </div>
  );
}
