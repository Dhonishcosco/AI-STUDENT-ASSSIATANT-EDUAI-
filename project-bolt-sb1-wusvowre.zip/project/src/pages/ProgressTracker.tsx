import { useState, useEffect } from 'react';
import { Plus, CheckCircle2, Clock, Trash2, BarChart3, Trophy, Code2, BookOpen, Award, Brain, Mic } from 'lucide-react';
import { supabase, ProgressRecord } from '../lib/supabase';

const categoryConfig: Record<ProgressRecord['category'], { label: string; icon: React.FC<{ size?: number; className?: string }>; color: string; bg: string }> = {
  skill: { label: 'Skill', icon: Code2, color: 'text-blue-400', bg: 'bg-blue-500/10' },
  certification: { label: 'Certification', icon: Award, color: 'text-amber-400', bg: 'bg-amber-500/10' },
  project: { label: 'Project', icon: BookOpen, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
  aptitude: { label: 'Aptitude', icon: Brain, color: 'text-purple-400', bg: 'bg-purple-500/10' },
  interview: { label: 'Interview', icon: Mic, color: 'text-pink-400', bg: 'bg-pink-500/10' },
};

const suggestions: { category: ProgressRecord['category']; title: string }[] = [
  { category: 'skill', title: 'Python Programming' },
  { category: 'skill', title: 'React.js Development' },
  { category: 'skill', title: 'SQL & Databases' },
  { category: 'certification', title: 'AWS Cloud Practitioner' },
  { category: 'certification', title: 'Google Data Analytics' },
  { category: 'project', title: 'Portfolio Website' },
  { category: 'project', title: 'Full Stack Web App' },
  { category: 'aptitude', title: 'Quantitative Aptitude (30 days)' },
  { category: 'interview', title: 'DSA Interview Practice' },
];

export default function ProgressTracker() {
  const [records, setRecords] = useState<ProgressRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ category: 'skill' as ProgressRecord['category'], title: '', description: '', score: '' });
  const [filterCategory, setFilterCategory] = useState<string>('all');

  useEffect(() => { loadRecords(); }, []);

  async function loadRecords() {
    const { data } = await supabase
      .from('progress_records')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setRecords(data);
    setLoading(false);
  }

  async function addRecord() {
    if (!form.title.trim()) return;
    const { data } = await supabase
      .from('progress_records')
      .insert({
        category: form.category,
        title: form.title,
        description: form.description,
        score: form.score ? parseInt(form.score) : null,
        status: 'in_progress',
      })
      .select()
      .maybeSingle();

    if (data) {
      setRecords((prev) => [data, ...prev]);
      setShowForm(false);
      setForm({ category: 'skill', title: '', description: '', score: '' });
    }
  }

  async function toggleComplete(record: ProgressRecord) {
    const newStatus = record.status === 'completed' ? 'in_progress' : 'completed';
    const update: Partial<ProgressRecord> = {
      status: newStatus,
      completed_at: newStatus === 'completed' ? new Date().toISOString() : null,
    };
    await supabase.from('progress_records').update(update).eq('id', record.id);
    setRecords((prev) => prev.map((r) => r.id === record.id ? { ...r, ...update } : r));
  }

  async function deleteRecord(id: string) {
    await supabase.from('progress_records').delete().eq('id', id);
    setRecords((prev) => prev.filter((r) => r.id !== id));
  }

  const completed = records.filter((r) => r.status === 'completed').length;
  const total = records.length;
  const readinessScore = total === 0 ? 0 : Math.min(100, Math.round(
    (completed / Math.max(total, 5)) * 50 +
    records.filter((r) => r.category === 'skill' && r.status === 'completed').length * 5 +
    records.filter((r) => r.category === 'certification' && r.status === 'completed').length * 8 +
    records.filter((r) => r.category === 'project' && r.status === 'completed').length * 7 +
    records.filter((r) => r.category === 'interview' && r.status === 'completed').length * 6
  ));

  const filtered = filterCategory === 'all' ? records : records.filter((r) => r.category === filterCategory);

  const categoryCounts = Object.keys(categoryConfig).reduce((acc, cat) => {
    acc[cat] = records.filter((r) => r.category === cat && r.status === 'completed').length;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="flex-1 overflow-y-auto p-6">
      <div className="max-w-5xl mx-auto">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="card p-4 rounded-xl lg:col-span-2">
            <div className="flex items-center gap-4">
              <div className="relative w-16 h-16 flex-shrink-0">
                <svg className="w-16 h-16 -rotate-90" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="38" fill="none" stroke="#1e293b" strokeWidth="12" />
                  <circle cx="50" cy="50" r="38" fill="none" stroke="#3b82f6"
                    strokeWidth="12"
                    strokeDasharray={`${readinessScore * 2.39} 239`}
                    strokeLinecap="round"
                    className="transition-all duration-700" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-lg font-display font-bold text-white">{readinessScore}</span>
                </div>
              </div>
              <div>
                <p className="text-lg font-display font-bold text-white">{completed}/{total}</p>
                <p className="text-sm text-slate-400">Milestones Completed</p>
                <p className="text-xs text-slate-600 mt-0.5">Placement Readiness Score</p>
              </div>
            </div>
          </div>
          {Object.entries(categoryConfig).slice(0, 2).map(([cat, config]) => {
            const Icon = config.icon;
            const count = records.filter((r) => r.category === cat).length;
            const done = records.filter((r) => r.category === cat && r.status === 'completed').length;
            return (
              <div key={cat} className="card p-4 rounded-xl">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-7 h-7 rounded-lg ${config.bg} flex items-center justify-center`}>
                    <Icon size={13} className={config.color} />
                  </div>
                  <span className="text-xs text-slate-400">{config.label}s</span>
                </div>
                <p className="text-2xl font-display font-bold text-white">{done}<span className="text-base text-slate-500">/{count}</span></p>
              </div>
            );
          })}
        </div>

        {/* Category breakdown */}
        <div className="card p-4 rounded-xl mb-6">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Progress by Category</p>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {Object.entries(categoryConfig).map(([cat, config]) => {
              const Icon = config.icon;
              const total = records.filter((r) => r.category === cat).length;
              const done = categoryCounts[cat] || 0;
              const pct = total > 0 ? Math.round((done / total) * 100) : 0;
              return (
                <div key={cat} className={`p-3 rounded-lg ${config.bg} text-center`}>
                  <Icon size={16} className={`${config.color} mx-auto mb-1`} />
                  <p className={`text-lg font-display font-bold ${config.color}`}>{pct}%</p>
                  <p className="text-xs text-slate-500">{config.label}</p>
                  <p className="text-xs text-slate-600">{done}/{total}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <div className="flex gap-1.5 flex-wrap flex-1">
            {['all', ...Object.keys(categoryConfig)].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors capitalize ${
                  filterCategory === cat ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat === 'all' ? 'All' : categoryConfig[cat as ProgressRecord['category']].label}
              </button>
            ))}
          </div>
          <button onClick={() => setShowForm(true)} className="btn-primary flex items-center gap-2 text-sm py-1.5 px-3">
            <Plus size={14} /> Add Milestone
          </button>
        </div>

        {/* Add form */}
        {showForm && (
          <div className="card p-5 rounded-xl mb-4 animate-slide-up">
            <h3 className="font-semibold text-white text-sm mb-4">Add New Milestone</h3>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">Category</label>
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value as ProgressRecord['category'] })}
                  className="input-field w-full text-sm"
                >
                  {Object.entries(categoryConfig).map(([cat, cfg]) => (
                    <option key={cat} value={cat}>{cfg.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1">Score / Progress (optional)</label>
                <input
                  type="number" min={0} max={100}
                  value={form.score}
                  onChange={(e) => setForm({ ...form, score: e.target.value })}
                  placeholder="e.g. 85"
                  className="input-field w-full text-sm"
                />
              </div>
            </div>
            <div className="mb-3">
              <label className="block text-xs text-slate-400 mb-1">Title</label>
              <input
                type="text"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="e.g. Completed Python Basics Course"
                className="input-field w-full text-sm"
              />
            </div>
            <div className="mb-4">
              <label className="block text-xs text-slate-400 mb-1">Notes (optional)</label>
              <input
                type="text"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                placeholder="Any additional notes..."
                className="input-field w-full text-sm"
              />
            </div>
            {/* Quick suggestions */}
            <div className="mb-4">
              <p className="text-xs text-slate-500 mb-2">Quick add:</p>
              <div className="flex flex-wrap gap-1.5">
                {suggestions.slice(0, 6).map((s) => (
                  <button
                    key={s.title}
                    onClick={() => setForm({ ...form, category: s.category, title: s.title })}
                    className="badge bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700 hover:border-slate-500 cursor-pointer transition-colors text-xs"
                  >
                    {s.title}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={addRecord} disabled={!form.title.trim()} className="btn-primary flex-1 text-sm py-2">Add Milestone</button>
              <button onClick={() => setShowForm(false)} className="btn-secondary flex-1 text-sm py-2">Cancel</button>
            </div>
          </div>
        )}

        {/* Records list */}
        {loading ? (
          <p className="text-slate-500 text-sm text-center py-8">Loading progress...</p>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <BarChart3 size={40} className="text-slate-700 mb-3" />
            <p className="text-slate-500 text-sm">No milestones tracked yet</p>
            <p className="text-slate-600 text-xs mt-1">Add your first milestone to start tracking!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map((record) => {
              const config = categoryConfig[record.category];
              const Icon = config.icon;
              return (
                <div
                  key={record.id}
                  className={`group flex items-center gap-4 card p-4 rounded-xl transition-all hover:bg-slate-800/50 ${
                    record.status === 'completed' ? 'opacity-75' : ''
                  } animate-fade-in`}
                >
                  <div className={`w-9 h-9 rounded-lg ${config.bg} flex items-center justify-center flex-shrink-0`}>
                    <Icon size={15} className={config.color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className={`text-sm font-medium ${record.status === 'completed' ? 'text-slate-400 line-through' : 'text-slate-200'}`}>
                        {record.title}
                      </p>
                      {record.score && (
                        <span className="badge bg-slate-800 text-slate-400 text-xs">{record.score}%</span>
                      )}
                    </div>
                    {record.description && <p className="text-xs text-slate-500 mt-0.5">{record.description}</p>}
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`badge border text-xs ${config.bg} ${config.color}`}>{config.label}</span>
                      {record.status === 'completed' ? (
                        <span className="flex items-center gap-1 text-xs text-emerald-400">
                          <CheckCircle2 size={10} /> Completed
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-xs text-slate-500">
                          <Clock size={10} /> In Progress
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => toggleComplete(record)}
                      className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors ${
                        record.status === 'completed'
                          ? 'bg-emerald-500/10 text-emerald-400 hover:bg-slate-800'
                          : 'bg-slate-800 text-slate-500 hover:text-emerald-400'
                      }`}
                    >
                      <CheckCircle2 size={14} />
                    </button>
                    <button
                      onClick={() => deleteRecord(record.id)}
                      className="w-7 h-7 rounded-lg bg-slate-800 flex items-center justify-center text-slate-500 hover:text-rose-400 transition-colors"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                  {record.status === 'completed' && (
                    <Trophy size={14} className="text-amber-400 flex-shrink-0" />
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
