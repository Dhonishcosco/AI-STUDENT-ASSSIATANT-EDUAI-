import { useState } from 'react';
import { Brain, CheckCircle2, XCircle, ChevronRight, RotateCcw, Trophy } from 'lucide-react';

type Question = {
  id: number;
  category: string;
  question: string;
  options: string[];
  answer: number;
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
};

const questionBank: Question[] = [
  {
    id: 1, category: 'Quantitative',
    question: 'A train 200m long travels at 60 km/h. How long does it take to pass a platform 100m long?',
    options: ['15 seconds', '18 seconds', '20 seconds', '12 seconds'],
    answer: 1,
    explanation: 'Total distance = 200 + 100 = 300m. Speed = 60 × 1000/3600 = 16.67 m/s. Time = 300/16.67 ≈ 18 seconds.',
    difficulty: 'Medium',
  },
  {
    id: 2, category: 'Quantitative',
    question: 'If 5 workers complete a job in 12 days, how many days do 10 workers need?',
    options: ['8 days', '6 days', '4 days', '10 days'],
    answer: 1,
    explanation: 'Total work = 5 × 12 = 60 man-days. With 10 workers: 60 / 10 = 6 days.',
    difficulty: 'Easy',
  },
  {
    id: 3, category: 'Quantitative',
    question: 'A number increased by 20% then decreased by 20%. What is the net % change?',
    options: ['-4%', '0%', '+4%', '-2%'],
    answer: 0,
    explanation: 'Let x = 100. After 20% increase: 120. After 20% decrease: 120 × 0.8 = 96. Net change = -4%.',
    difficulty: 'Medium',
  },
  {
    id: 4, category: 'Logical Reasoning',
    question: 'Find the next number: 2, 6, 12, 20, 30, ?',
    options: ['40', '42', '44', '38'],
    answer: 1,
    explanation: 'Differences: 4, 6, 8, 10, 12. Next difference = 12. So 30 + 12 = 42.',
    difficulty: 'Easy',
  },
  {
    id: 5, category: 'Logical Reasoning',
    question: 'All cats are animals. All animals are living beings. Which is definitely true?',
    options: ['All living beings are cats', 'All cats are living beings', 'All animals are cats', 'Some living beings are not animals'],
    answer: 1,
    explanation: 'By transitive syllogism: Cats → Animals → Living beings. Therefore all cats are living beings.',
    difficulty: 'Easy',
  },
  {
    id: 6, category: 'Verbal Ability',
    question: 'Choose the correct synonym for "LUCID":',
    options: ['Murky', 'Clear', 'Dark', 'Confused'],
    answer: 1,
    explanation: '"Lucid" means clear, easy to understand, or transparent. The correct synonym is "Clear".',
    difficulty: 'Easy',
  },
  {
    id: 7, category: 'Quantitative',
    question: 'A and B can do work in 12 and 18 days. How many days together?',
    options: ['6 days', '7.2 days', '8 days', '9 days'],
    answer: 1,
    explanation: 'Combined rate = 1/12 + 1/18 = 3/36 + 2/36 = 5/36. Time = 36/5 = 7.2 days.',
    difficulty: 'Medium',
  },
  {
    id: 8, category: 'Quantitative',
    question: 'What is 15% of 280?',
    options: ['38', '40', '42', '44'],
    answer: 2,
    explanation: '15% of 280 = (15/100) × 280 = 0.15 × 280 = 42.',
    difficulty: 'Easy',
  },
  {
    id: 9, category: 'Logical Reasoning',
    question: 'A is taller than B. C is taller than A. D is shorter than B. Who is the shortest?',
    options: ['A', 'B', 'C', 'D'],
    answer: 3,
    explanation: 'Order: C > A > B > D. So D is the shortest.',
    difficulty: 'Easy',
  },
  {
    id: 10, category: 'Verbal Ability',
    question: 'Identify the correctly spelled word:',
    options: ['Accomodation', 'Accommodation', 'Accomadation', 'Acomodation'],
    answer: 1,
    explanation: 'The correct spelling is "Accommodation" with double "c" and double "m".',
    difficulty: 'Medium',
  },
];

const categoryColors: Record<string, string> = {
  Quantitative: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
  'Logical Reasoning': 'bg-purple-500/10 text-purple-400 border-purple-500/20',
  'Verbal Ability': 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
};

const difficultyColors: Record<string, string> = {
  Easy: 'text-emerald-400',
  Medium: 'text-amber-400',
  Hard: 'text-rose-400',
};

export default function AptitudeTrainer() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(0);
  const [filter, setFilter] = useState<string>('All');
  const [completed, setCompleted] = useState(false);

  const categories = ['All', 'Quantitative', 'Logical Reasoning', 'Verbal Ability'];
  const filtered = filter === 'All' ? questionBank : questionBank.filter((q) => q.category === filter);
  const question = filtered[currentIndex % filtered.length];

  function selectAnswer(idx: number) {
    if (selected !== null) return;
    setSelected(idx);
    setShowExplanation(true);
    setAnswered((a) => a + 1);
    if (idx === question.answer) setScore((s) => s + 1);
  }

  function next() {
    if (currentIndex + 1 >= filtered.length) {
      setCompleted(true);
      return;
    }
    setCurrentIndex((i) => i + 1);
    setSelected(null);
    setShowExplanation(false);
  }

  function reset() {
    setCurrentIndex(0);
    setSelected(null);
    setShowExplanation(false);
    setScore(0);
    setAnswered(0);
    setCompleted(false);
  }

  const accuracy = answered > 0 ? Math.round((score / answered) * 100) : 0;

  if (completed) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="text-center max-w-sm">
          <div className="w-20 h-20 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-4">
            <Trophy size={32} className="text-amber-400" />
          </div>
          <h2 className="font-display font-bold text-white text-2xl mb-2">Quiz Complete!</h2>
          <p className="text-slate-400 text-sm mb-6">You answered {answered} questions</p>
          <div className="grid grid-cols-2 gap-3 mb-6">
            <div className="card p-4 rounded-xl text-center">
              <p className="text-3xl font-display font-bold text-white">{score}/{answered}</p>
              <p className="text-xs text-slate-500 mt-1">Correct</p>
            </div>
            <div className="card p-4 rounded-xl text-center">
              <p className={`text-3xl font-display font-bold ${accuracy >= 70 ? 'text-emerald-400' : accuracy >= 50 ? 'text-amber-400' : 'text-rose-400'}`}>{accuracy}%</p>
              <p className="text-xs text-slate-500 mt-1">Accuracy</p>
            </div>
          </div>
          <p className="text-slate-400 text-sm mb-6">
            {accuracy >= 80 ? 'Excellent! You are well-prepared for aptitude tests.' :
             accuracy >= 60 ? 'Good progress! Focus on weak areas and practice more.' :
             'Keep practicing! Review explanations and try again.'}
          </p>
          <button onClick={reset} className="btn-primary flex items-center gap-2 mx-auto">
            <RotateCcw size={15} /> Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-6 max-w-3xl mx-auto w-full">
      {/* Header stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="card p-3 rounded-xl text-center">
          <p className="text-xl font-display font-bold text-white">{score}</p>
          <p className="text-xs text-slate-500">Correct</p>
        </div>
        <div className="card p-3 rounded-xl text-center">
          <p className="text-xl font-display font-bold text-white">{answered}</p>
          <p className="text-xs text-slate-500">Attempted</p>
        </div>
        <div className="card p-3 rounded-xl text-center">
          <p className={`text-xl font-display font-bold ${accuracy >= 70 ? 'text-emerald-400' : accuracy >= 50 ? 'text-amber-400' : 'text-rose-400'}`}>{accuracy}%</p>
          <p className="text-xs text-slate-500">Accuracy</p>
        </div>
      </div>

      {/* Category filter */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => { setFilter(cat); setCurrentIndex(0); setSelected(null); setShowExplanation(false); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              filter === cat ? 'bg-blue-600 text-white' : 'bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Progress */}
      <div className="flex items-center gap-3 mb-6">
        <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-blue-500 rounded-full transition-all duration-300"
            style={{ width: `${((currentIndex + 1) / filtered.length) * 100}%` }}
          />
        </div>
        <span className="text-xs text-slate-500 flex-shrink-0">{currentIndex + 1} / {filtered.length}</span>
      </div>

      {/* Question card */}
      <div className="card p-6 rounded-2xl mb-4 animate-fade-in">
        <div className="flex items-center justify-between mb-4">
          <span className={`badge border ${categoryColors[question.category] || 'bg-slate-500/10 text-slate-400'}`}>
            {question.category}
          </span>
          <span className={`text-xs font-medium ${difficultyColors[question.difficulty]}`}>
            {question.difficulty}
          </span>
        </div>

        <p className="text-base text-slate-100 font-medium mb-6 leading-relaxed">{question.question}</p>

        <div className="space-y-2.5">
          {question.options.map((opt, i) => {
            let style = 'bg-slate-800/50 border-slate-700 text-slate-300 hover:border-slate-500 hover:bg-slate-800';
            if (selected !== null) {
              if (i === question.answer) style = 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300';
              else if (i === selected && selected !== question.answer) style = 'bg-rose-500/10 border-rose-500/40 text-rose-300';
              else style = 'bg-slate-800/30 border-slate-800 text-slate-500';
            }

            return (
              <button
                key={i}
                onClick={() => selectAnswer(i)}
                className={`w-full text-left px-4 py-3 rounded-xl border transition-all duration-150 text-sm ${style} flex items-center gap-3`}
              >
                <span className="w-5 h-5 rounded-full border border-current flex items-center justify-center flex-shrink-0 text-xs font-bold">
                  {String.fromCharCode(65 + i)}
                </span>
                <span className="flex-1">{opt}</span>
                {selected !== null && i === question.answer && <CheckCircle2 size={15} className="text-emerald-400 flex-shrink-0" />}
                {selected !== null && i === selected && selected !== question.answer && <XCircle size={15} className="text-rose-400 flex-shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Explanation */}
      {showExplanation && (
        <div className="card p-4 rounded-xl mb-4 animate-slide-up border-l-4 border-blue-500">
          <div className="flex items-center gap-2 mb-2">
            <Brain size={14} className="text-blue-400" />
            <span className="text-xs font-semibold text-blue-400 uppercase tracking-wider">Explanation</span>
          </div>
          <p className="text-sm text-slate-300 leading-relaxed">{question.explanation}</p>
        </div>
      )}

      {selected !== null && (
        <button onClick={next} className="btn-primary w-full flex items-center justify-center gap-2 py-3">
          {currentIndex + 1 >= filtered.length ? 'View Results' : 'Next Question'}
          <ChevronRight size={16} />
        </button>
      )}
    </div>
  );
}
