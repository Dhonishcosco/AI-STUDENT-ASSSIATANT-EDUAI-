import { useState, useEffect } from 'react';
import { Plus, Calendar, Clock, CheckCircle2, Trash2, BookOpen, TrendingUp } from 'lucide-react';
import { supabase, StudyPlan, StudyDay } from '../lib/supabase';

const SUBJECTS = [
  'Data Structures & Algorithms', 'Database Management Systems', 'Operating Systems',
  'Computer Networks', 'Python Programming', 'Java Programming', 'Machine Learning',
  'Web Development', 'Software Engineering', 'Digital Electronics',
  'Engineering Mathematics', 'Object Oriented Programming',
];

function generateSchedule(subject: string, days: number, hoursPerDay: number): StudyDay[] {
  const schedule: StudyDay[] = [];
  const phase1 = Math.floor(days * 0.4);
  const phase2 = Math.floor(days * 0.3);
  const phase3 = Math.floor(days * 0.2);
  const phase4 = days - phase1 - phase2 - phase3;

  for (let i = 0; i < days; i++) {
    let type: StudyDay['type'] = 'learn';
    let topics: string[] = [];

    if (i < phase1) {
      type = 'learn';
      topics = [`${subject} — Core Concepts (Part ${i + 1})`, 'Theory & Definitions', 'Textbook Reading'];
    } else if (i < phase1 + phase2) {
      type = 'practice';
      topics = [`Practice Problems — Set ${i - phase1 + 1}`, 'Solved Examples', 'Previous Year Questions'];
    } else if (i < phase1 + phase2 + phase3) {
      type = i % 3 === 0 ? 'mock' : 'revise';
      topics = i % 3 === 0
        ? ['Full Mock Test', 'Time-bound Practice', 'Error Analysis']
        : [`Revision — Module ${i - phase1 - phase2 + 1}`, 'Mind Maps & Notes', 'Flash Cards'];
    } else {
      type = 'revise';
      topics = ['Final Revision', 'Key Formula Sheet', 'Quick Notes Review'];
    }

    schedule.push({ day: i + 1, topics, hours: hoursPerDay, type });
  }

  return schedule;
}

const typeColors: Record<StudyDay['type'], string> = {
  learn: 'bg-blue-500/15 text-blue-400 border-blue-500/20',
  practice: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20',
  revise: 'bg-amber-500/15 text-amber-400 border-amber-500/20',
  mock: 'bg-rose-500/15 text-rose-400 border-rose-500/20',
};

const typeLabels: Record<StudyDay['type'], string> = {
  learn: 'Learn',
  practice: 'Practice',
  revise: 'Revise',
  mock: 'Mock Test',
};

export default function StudyPlanner() {
  const [plans, setPlans] = useState<StudyPlan[]>([]);
  const [activePlan, setActivePlan] = useState<StudyPlan | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({
    subject: '',
    available_days: 30,
    daily_hours: 4,
    exam_date: '',
  });

  useEffect(() => { loadPlans(); }, []);

  async function loadPlans() {
    const { data } = await supabase
      .from('study_plans')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) {
      setPlans(data);
      if (data.length > 0) setActivePlan(data[0]);
    }
    setLoading(false);
  }

  async function createPlan() {
    if (!form.subject) return;
    const schedule = generateSchedule(form.subject, form.available_days, form.daily_hours);
    const { data } = await supabase
      .from('study_plans')
      .insert({ ...form, schedule, exam_date: form.exam_date || null })
      .select()
      .maybeSingle();

    if (data) {
      setPlans((prev) => [data, ...prev]);
      setActivePlan(data);
      setShowForm(false);
      setForm({ subject: '', available_days: 30, daily_hours: 4, exam_date: '' });
    }
  }

  async function deletePlan(id: string) {
    await supabase.from('study_plans').delete().eq('id', id);
    setPlans((prev) => prev.filter((p) => p.id !== id));
    if (activePlan?.id === id) setActivePlan(plans.find((p) => p.id !== id) || null);
  }

  async function toggleStatus(plan: StudyPlan) {
    const newStatus = plan.status === 'active' ? 'completed' : 'active';
    await supabase.from('study_plans').update({ status: newStatus }).eq('id', plan.id);
    setPlans((prev) => prev.map((p) => p.id === plan.id ? { ...p, status: newStatus } : p));
    if (activePlan?.id === plan.id) setActivePlan({ ...plan, status: newStatus });
  }

  const stats = activePlan ? {
    total: activePlan.schedule.length,
    learn: activePlan.schedule.filter((d) => d.type === 'learn').length,
    practice: activePlan.schedule.filter((d) => d.type === 'practice').length,
    revise: activePlan.schedule.filter((d) => d.type === 'revise').length,
    mock: activePlan.schedule.filter((d) => d.type === 'mock').length,
    totalHours: activePlan.schedule.reduce((acc, d) => acc + d.hours, 0),
  } : null;

  return (
    <div className="flex flex-1 min-h-0">
      {/* Plans list */}
      <div className="w-64 flex-shrink-0 border-r border-slate-800 flex flex-col">
        <div className="p-3 border-b border-slate-800">
          <button onClick={() => setShowForm(true)} className="btn-primary w-full flex items-center justify-center gap-2 py-2 text-sm">
            <Plus size={15} /> New Study Plan
          </button>
        </div>
        <div className="flex-1 overflow-y-auto py-2 space-y-1 px-2 scrollbar-hide">
          {loading ? (
            <p className="text-xs text-slate-500 px-3 py-4 text-center">Loading plans...</p>
          ) : plans.length === 0 ? (
            <div className="px-3 py-8 text-center">
              <BookOpen size={28} className="text-slate-700 mx-auto mb-2" />
              <p className="text-xs text-slate-500">No study plans yet.</p>
              <p className="text-xs text-slate-600 mt-1">Create your first plan!</p>
            </div>
          ) : plans.map((plan) => (
            <div
              key={plan.id}
              onClick={() => setActivePlan(plan)}
              className={`group px-3 py-3 rounded-lg cursor-pointer transition-colors ${
                activePlan?.id === plan.id ? 'bg-blue-600/15 border border-blue-500/20' : 'hover:bg-slate-800/60 border border-transparent'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-slate-200 truncate">{plan.subject}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{plan.available_days} days · {plan.daily_hours}h/day</p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <span className={`badge ${plan.status === 'completed' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'}`}>
                    {plan.status}
                  </span>
                  <button
                    onClick={(e) => { e.stopPropagation(); deletePlan(plan.id); }}
                    className="opacity-0 group-hover:opacity-100 text-slate-600 hover:text-rose-400 transition-all ml-1"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Plan detail */}
      <div className="flex-1 overflow-y-auto">
        {showForm ? (
          <div className="max-w-lg mx-auto p-6">
            <h2 className="font-display font-semibold text-white text-lg mb-6">Create Study Plan</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-400 mb-1.5">Subject</label>
                <select
                  value={form.subject}
                  onChange={(e) => setForm({ ...form, subject: e.target.value })}
                  className="input-field w-full"
                >
                  <option value="">Select a subject...</option>
                  {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Available Days</label>
                  <input
                    type="number" min={7} max={180}
                    value={form.available_days}
                    onChange={(e) => setForm({ ...form, available_days: parseInt(e.target.value) || 30 })}
                    className="input-field w-full"
                  />
                </div>
                <div>
                  <label className="block text-sm text-slate-400 mb-1.5">Hours Per Day</label>
                  <input
                    type="number" min={1} max={12}
                    value={form.daily_hours}
                    onChange={(e) => setForm({ ...form, daily_hours: parseInt(e.target.value) || 4 })}
                    className="input-field w-full"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm text-slate-400 mb-1.5">Exam Date (optional)</label>
                <input
                  type="date"
                  value={form.exam_date}
                  onChange={(e) => setForm({ ...form, exam_date: e.target.value })}
                  className="input-field w-full"
                />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={createPlan} disabled={!form.subject} className="btn-primary flex-1">
                  Generate Plan
                </button>
                <button onClick={() => setShowForm(false)} className="btn-secondary flex-1">
                  Cancel
                </button>
              </div>
            </div>
          </div>
        ) : activePlan ? (
          <div className="p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="font-display font-bold text-white text-xl">{activePlan.subject}</h2>
                <p className="text-slate-500 text-sm mt-1">
                  {activePlan.available_days} days · {activePlan.daily_hours} hrs/day
                  {activePlan.exam_date && ` · Exam: ${new Date(activePlan.exam_date).toLocaleDateString()}`}
                </p>
              </div>
              <button
                onClick={() => toggleStatus(activePlan)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  activePlan.status === 'completed'
                    ? 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <CheckCircle2 size={14} />
                {activePlan.status === 'completed' ? 'Completed' : 'Mark Complete'}
              </button>
            </div>

            {/* Stats */}
            {stats && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
                {[
                  { label: 'Total Days', value: stats.total, icon: Calendar, color: 'text-blue-400' },
                  { label: 'Total Hours', value: stats.totalHours, icon: Clock, color: 'text-amber-400' },
                  { label: 'Practice Days', value: stats.practice, icon: TrendingUp, color: 'text-emerald-400' },
                  { label: 'Mock Tests', value: stats.mock, icon: CheckCircle2, color: 'text-rose-400' },
                ].map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <div key={stat.label} className="card p-3 rounded-lg">
                      <div className="flex items-center gap-2 mb-1">
                        <Icon size={14} className={stat.color} />
                        <span className="text-xs text-slate-500">{stat.label}</span>
                      </div>
                      <p className="text-2xl font-display font-bold text-white">{stat.value}</p>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Legend */}
            <div className="flex flex-wrap gap-2 mb-4">
              {Object.entries(typeLabels).map(([type, label]) => (
                <span key={type} className={`badge border ${typeColors[type as StudyDay['type']]}`}>
                  {label}
                </span>
              ))}
            </div>

            {/* Schedule */}
            <div className="space-y-2">
              {activePlan.schedule.map((day) => (
                <div key={day.day} className="flex items-start gap-3 card p-3 rounded-lg hover:bg-slate-800/60 transition-colors">
                  <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-bold text-slate-300">{day.day}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`badge border text-xs ${typeColors[day.type]}`}>{typeLabels[day.type]}</span>
                      <span className="text-xs text-slate-500">{day.hours}h</span>
                    </div>
                    <div className="space-y-0.5">
                      {day.topics.map((topic, i) => (
                        <p key={i} className="text-sm text-slate-300 truncate">{topic}</p>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <BookOpen size={48} className="text-slate-700 mb-4" />
            <h3 className="font-display font-semibold text-slate-400 text-lg mb-2">No Study Plans Yet</h3>
            <p className="text-slate-600 text-sm mb-4">Create a personalized study plan to get started</p>
            <button onClick={() => setShowForm(true)} className="btn-primary flex items-center gap-2">
              <Plus size={15} /> Create Study Plan
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
