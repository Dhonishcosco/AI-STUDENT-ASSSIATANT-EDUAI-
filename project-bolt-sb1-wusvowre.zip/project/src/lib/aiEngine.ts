export type AIMode =
  | 'general'
  | 'study'
  | 'career'
  | 'placement'
  | 'resume'
  | 'aptitude'
  | 'interview'
  | 'skills'
  | 'progress';

const TYPING_DELAY = 800;

export async function generateResponse(
  userMessage: string,
  mode: AIMode,
  conversationHistory: { role: string; content: string }[]
): Promise<string> {
  await new Promise((r) => setTimeout(r, TYPING_DELAY));

  const msg = userMessage.toLowerCase();

  if (mode === 'interview') return generateInterviewResponse(msg, conversationHistory);
  if (mode === 'study') return generateStudyResponse(msg);
  if (mode === 'career') return generateCareerResponse(msg);
  if (mode === 'placement') return generatePlacementResponse(msg);
  if (mode === 'resume') return generateResumeResponse(msg);
  if (mode === 'aptitude') return generateAptitudeResponse(msg);
  if (mode === 'skills') return generateSkillsResponse(msg);

  return generateGeneralResponse(msg, conversationHistory);
}

function generateGeneralResponse(
  msg: string,
  history: { role: string; content: string }[]
): string {
  if (msg.includes('hello') || msg.includes('hi') || msg.includes('hey') || history.length === 0) {
    return `## Welcome to EDUAI!

I am your **AI-Powered Student Assistant**, here to help you excel in every aspect of your academic and professional journey.

Here is what I can help you with:

| Feature | Description |
|---|---|
| **Study Assistant** | Explain concepts, generate study plans |
| **Career Guidance** | Career path recommendations based on your profile |
| **Placement Prep** | Evaluate placement readiness with a score |
| **Resume Analyzer** | ATS score, improvements, and suggestions |
| **Aptitude Coach** | Quant, logical reasoning, verbal training |
| **Interview Trainer** | Mock interviews with AI feedback |
| **Skill Development** | Course & certification recommendations |
| **Progress Tracker** | Track milestones and growth |

### How to Get Started

- Use the **sidebar** to switch between modes
- Or simply ask me anything right here!

**What would you like to work on today?**`;
  }

  if (msg.includes('data structure') || msg.includes('algorithm') || msg.includes('linked list') || msg.includes('tree') || msg.includes('graph')) {
    return generateDSAResponse(msg);
  }

  if (msg.includes('python') || msg.includes('java') || msg.includes('c++') || msg.includes('javascript')) {
    return generateProgrammingResponse(msg);
  }

  if (msg.includes('dbms') || msg.includes('database') || msg.includes('sql') || msg.includes('normalization')) {
    return generateDBMSResponse(msg);
  }

  if (msg.includes('os') || msg.includes('operating system') || msg.includes('process') || msg.includes('thread') || msg.includes('deadlock')) {
    return generateOSResponse(msg);
  }

  if (msg.includes('network') || msg.includes('tcp') || msg.includes('osi') || msg.includes('protocol')) {
    return generateNetworkResponse(msg);
  }

  return `## EDUAI Response

Thank you for your question! Let me help you with that.

**Your query:** "${msg}"

To give you the most accurate and personalized guidance, could you tell me:

1. **Your department/branch** (e.g., Computer Science, Electronics, Mechanical)
2. **Your current year of study** (1st, 2nd, 3rd, 4th year)
3. **What specific help you need** (concept explanation, study plan, career advice, etc.)

Alternatively, you can use the **specialized modes** in the sidebar:

- **Study Mode** — for academic concepts and planning
- **Career Mode** — for career path guidance
- **Placement Mode** — for placement readiness evaluation
- **Interview Mode** — for mock technical interviews

I am here to help you succeed! What would you like to explore?`;
}

function generateDSAResponse(msg: string): string {
  if (msg.includes('linked list')) {
    return `## Linked List — Complete Guide

### Definition
A **Linked List** is a linear data structure where elements (nodes) are stored in non-contiguous memory locations and connected via pointers.

### Types
| Type | Description |
|---|---|
| Singly Linked List | Each node has data + next pointer |
| Doubly Linked List | Each node has data + next + prev pointer |
| Circular Linked List | Last node points back to first node |

### Node Structure (C++)
\`\`\`cpp
struct Node {
    int data;
    Node* next;
    Node(int val) : data(val), next(nullptr) {}
};
\`\`\`

### Key Operations & Time Complexity
| Operation | Time Complexity |
|---|---|
| Insertion at head | O(1) |
| Insertion at tail | O(n) |
| Deletion | O(n) |
| Search | O(n) |
| Access by index | O(n) |

### Advantages over Arrays
- Dynamic size
- Efficient insertion/deletion at head

### Disadvantages
- No random access
- Extra memory for pointers
- Cache unfriendly

### Important Viva Questions
1. What is the difference between array and linked list?
2. How do you detect a cycle in a linked list? (Floyd's algorithm)
3. How do you reverse a linked list?
4. What is the difference between singly and doubly linked list?

### Key Takeaways
- Use when frequent insertions/deletions are needed
- Arrays are better when random access is required
- Foundation for stacks, queues, and graphs`;
  }

  return `## Data Structures & Algorithms

### Core Topics to Master

**Linear Data Structures**
- Arrays, Strings
- Linked Lists (Singly, Doubly, Circular)
- Stacks, Queues, Deques

**Non-Linear Data Structures**
- Trees (Binary, BST, AVL, Heap)
- Graphs (BFS, DFS, Shortest Path)
- Hash Tables

**Algorithm Paradigms**
| Paradigm | Example Problems |
|---|---|
| Divide & Conquer | Merge Sort, Quick Sort |
| Dynamic Programming | Knapsack, LCS, LIS |
| Greedy | Prim's, Kruskal's, Dijkstra's |
| Backtracking | N-Queens, Sudoku |

### Complexity Reference
| Algorithm | Best | Average | Worst |
|---|---|---|---|
| Bubble Sort | O(n) | O(n²) | O(n²) |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) |
| Quick Sort | O(n log n) | O(n log n) | O(n²) |
| Binary Search | O(1) | O(log n) | O(log n) |

**Which specific topic would you like to dive into?**`;
}

function generateProgrammingResponse(msg: string): string {
  return `## Programming Concepts

### Python — Key Topics for Placement
\`\`\`python
# Object-Oriented Programming
class Student:
    def __init__(self, name, cgpa):
        self.name = name
        self.cgpa = cgpa

    def is_placement_eligible(self):
        return self.cgpa >= 6.0

# List Comprehension
scores = [85, 92, 78, 95, 88]
above_avg = [s for s in scores if s > sum(scores)/len(scores)]

# Decorators, Generators, Lambda — frequently tested
squares = list(map(lambda x: x**2, range(10)))
\`\`\`

### Important Interview Topics
1. **OOP Concepts** — Inheritance, Polymorphism, Encapsulation, Abstraction
2. **Collections** — List, Tuple, Set, Dictionary differences
3. **Exception Handling** — try/except/finally
4. **File I/O** — Reading and writing files
5. **Modules & Libraries** — NumPy, Pandas (for Data Science roles)

### Practice Platforms
- **LeetCode** — Algorithm problems (must for FAANG)
- **HackerRank** — Language-specific challenges
- **GeeksforGeeks** — Theory + practice combined
- **Codeforces** — Competitive programming

### Recommended Learning Path
1. Core language syntax (Week 1)
2. OOP concepts (Week 2)
3. Data Structures implementation (Week 3-4)
4. Problem solving — 2 problems/day (Ongoing)

**What specific programming concept would you like to explore?**`;
}

function generateDBMSResponse(msg: string): string {
  return `## DBMS — Database Management Systems

### Core Concepts

**1. Normalization**
| Normal Form | Condition |
|---|---|
| 1NF | Atomic values, no repeating groups |
| 2NF | 1NF + No partial dependency |
| 3NF | 2NF + No transitive dependency |
| BCNF | 3NF + Every determinant is a candidate key |

**2. ACID Properties**
- **Atomicity** — Transaction completes fully or not at all
- **Consistency** — Database remains consistent before and after
- **Isolation** — Concurrent transactions don't interfere
- **Durability** — Committed data persists

**3. SQL — Key Statements**
\`\`\`sql
-- Joins
SELECT s.name, c.course_name
FROM students s
INNER JOIN courses c ON s.course_id = c.id;

-- Aggregate functions
SELECT dept, AVG(cgpa) as avg_cgpa, COUNT(*) as total
FROM students
GROUP BY dept
HAVING AVG(cgpa) > 7.0;

-- Subquery
SELECT name FROM students
WHERE cgpa > (SELECT AVG(cgpa) FROM students);
\`\`\`

### Frequently Asked Viva Questions
1. Difference between DELETE, TRUNCATE, DROP?
2. What is a deadlock? How is it handled?
3. Explain B+ Tree index structure.
4. Difference between clustered and non-clustered index?
5. What are triggers and stored procedures?

### Key Takeaways
- Normalization eliminates data redundancy
- Indexes improve query performance
- Transactions ensure data integrity`;
}

function generateOSResponse(msg: string): string {
  return `## Operating Systems — Core Concepts

### Process vs Thread
| Aspect | Process | Thread |
|---|---|---|
| Definition | Program in execution | Lightweight process |
| Memory | Separate address space | Shared address space |
| Communication | IPC required | Direct sharing |
| Creation time | Slower | Faster |
| Context switch | Expensive | Cheap |

### CPU Scheduling Algorithms
| Algorithm | Type | Starvation? |
|---|---|---|
| FCFS | Non-preemptive | No |
| SJF | Non-preemptive | Yes |
| Round Robin | Preemptive | No |
| Priority | Both | Yes |

### Deadlock — 4 Conditions (Coffman)
1. **Mutual Exclusion** — Only one process can use a resource
2. **Hold and Wait** — Process holds resources while waiting
3. **No Preemption** — Resources can't be forcibly taken
4. **Circular Wait** — Circular chain of waiting processes

### Memory Management
- **Paging** — Fixed-size blocks, no external fragmentation
- **Segmentation** — Variable-size blocks, logical division
- **Virtual Memory** — Demand paging, page replacement (LRU, FIFO, Optimal)

### Common Interview Questions
1. What is a race condition? How to prevent it?
2. Explain semaphore vs mutex.
3. What is thrashing?
4. Explain the working of LRU page replacement.`;
}

function generateNetworkResponse(msg: string): string {
  return `## Computer Networks — Key Concepts

### OSI Model — 7 Layers
| Layer | Name | Protocol Examples |
|---|---|---|
| 7 | Application | HTTP, FTP, SMTP, DNS |
| 6 | Presentation | SSL/TLS, JPEG |
| 5 | Session | NetBIOS, RPC |
| 4 | Transport | TCP, UDP |
| 3 | Network | IP, ICMP, OSPF |
| 2 | Data Link | Ethernet, MAC, ARP |
| 1 | Physical | Cables, Wi-Fi |

### TCP vs UDP
| Feature | TCP | UDP |
|---|---|---|
| Connection | Connection-oriented | Connectionless |
| Reliability | Reliable | Unreliable |
| Speed | Slower | Faster |
| Use case | Web, Email, File transfer | Video, VoIP, DNS |

### Important Protocols
- **HTTP/HTTPS** — Web communication (port 80/443)
- **DNS** — Domain name resolution (port 53)
- **DHCP** — Dynamic IP assignment
- **ARP** — IP to MAC address resolution

### Subnetting
\`\`\`
IP: 192.168.1.0/24
Subnet Mask: 255.255.255.0
Hosts: 254 (2^8 - 2)
Network: 192.168.1.0
Broadcast: 192.168.1.255
\`\`\`

### Frequently Asked Questions
1. What is the 3-way handshake in TCP?
2. What happens when you type a URL?
3. Difference between router and switch?
4. What is NAT and why is it used?`;
}

function generateStudyResponse(msg: string): string {
  if (msg.includes('plan') || msg.includes('schedule') || msg.includes('exam')) {
    return `## Personalized Study Plan Generator

To create your optimal study plan, I need a few details:

### Please provide:
1. **Subject** — e.g., Data Structures, DBMS, Machine Learning
2. **Exam date** — How many days from today?
3. **Daily study hours** — How many hours can you dedicate?
4. **Current level** — Beginner / Intermediate / Advanced

### Example Plan Structure (30 Days, 4 hrs/day)

**Week 1 — Foundation** (Days 1–7)
- Days 1–3: Core concepts and theory
- Days 4–5: Examples and problem solving
- Days 6–7: First revision + mini quiz

**Week 2 — Deep Dive** (Days 8–14)
- Days 8–11: Advanced topics
- Days 12–13: Difficult problems
- Day 14: Week revision

**Week 3 — Practice** (Days 15–21)
- Days 15–18: Previous year questions
- Days 19–20: Mock tests
- Day 21: Analyze weak areas

**Week 4 — Revision** (Days 22–30)
- Days 22–26: Complete revision
- Days 27–28: Final mock tests
- Days 29–30: Light review only

### Study Tips
- Use the **Pomodoro Technique**: 25 min study + 5 min break
- Review notes within **24 hours** of learning (retention increases by 80%)
- Practice **active recall** instead of passive re-reading

**Use the Study Planner tool in the sidebar to generate a detailed, personalized plan!**`;
  }

  return `## Study Assistant

I can help you with:

### Academic Support
- **Concept Explanations** — Any engineering subject
- **Study Plans** — Customized day-by-day schedules
- **Viva Preparation** — Key questions per topic
- **Revision Strategies** — Smart review techniques

### Available Subjects
| Domain | Topics |
|---|---|
| Programming | Python, Java, C++, JavaScript |
| CS Fundamentals | DSA, DBMS, OS, CN |
| Mathematics | Discrete Math, Linear Algebra, Probability |
| Electronics | Digital Circuits, Microprocessors |

### Learning Strategies
1. **Spaced Repetition** — Review at increasing intervals
2. **Active Recall** — Test yourself without looking at notes
3. **Mind Mapping** — Visual connections between concepts
4. **Teach-Back Method** — Explain concepts to solidify understanding

**What subject or concept would you like to study today?**`;
}

function generateCareerResponse(msg: string): string {
  return `## Career Guidance Analysis

### Career Path Recommendations

Based on a typical CS/Engineering profile, here are the top career paths:

| Career Path | Required Skills | Avg Package (LPA) | Demand |
|---|---|---|---|
| Software Development | DSA, System Design, OOP | 8–25 | Very High |
| Data Science/ML | Python, ML, Statistics, SQL | 8–20 | High |
| DevOps/Cloud | AWS/GCP, Docker, CI/CD | 10–22 | High |
| Cybersecurity | Networking, Linux, Security | 8–18 | Growing |
| Product Management | Communication, Analytics, Leadership | 12–30 | Moderate |
| Full Stack Dev | React, Node.js, Databases | 7–18 | High |

### Learning Roadmap — Software Development
**Phase 1: Foundation** (3–6 months)
- Data Structures & Algorithms
- One programming language (Python/Java)
- Git & Version Control

**Phase 2: Core Skills** (3–6 months)
- System Design basics
- Database design (SQL + NoSQL)
- REST APIs

**Phase 3: Specialization** (3–6 months)
- Choose: Backend / Frontend / Mobile / ML
- Build 2–3 projects
- Open source contributions

### Top Certifications by Domain
- **Cloud** — AWS Solutions Architect, Google Cloud Associate
- **Data Science** — Google Data Analytics, IBM Data Science
- **Web Dev** — Meta Front-End Developer, freeCodeCamp
- **Security** — CompTIA Security+, CEH

### Action Plan
1. **Assess** your current skills honestly
2. **Choose** one primary career path
3. **Build** a focused learning plan (6–12 months)
4. **Create** 2–3 portfolio projects
5. **Apply** for internships to gain experience

**Share your department, CGPA, and interests for personalized recommendations!**`;
}

function generatePlacementResponse(msg: string): string {
  return `## Placement Readiness Evaluation

### Placement Readiness Score Framework

To calculate your personalized score, rate yourself (1–10) on:

| Criteria | Weight | Your Score |
|---|---|---|
| Technical Skills | 30% | — |
| DSA / Problem Solving | 25% | — |
| Projects & Portfolio | 20% | — |
| Communication Skills | 15% | — |
| Aptitude Preparation | 10% | — |

### Score Interpretation
| Range | Category | What It Means |
|---|---|---|
| 0–40 | Beginner | Significant preparation needed |
| 41–60 | Developing | Good foundation, needs polish |
| 61–80 | Placement Ready | Competitive for most companies |
| 81–100 | Highly Competitive | Ready for top-tier companies |

### Company Tiers & Requirements
**Tier 1 (FAANG, MNCs)** — Score 80+
- Strong DSA (LeetCode Medium/Hard)
- System Design knowledge
- 1+ internship experience

**Tier 2 (Mid-size tech companies)** — Score 60–80
- Solid DSA fundamentals
- 2–3 good projects
- Good communication

**Tier 3 (Service companies, startups)** — Score 40–60
- Basic programming skills
- Academic projects
- Decent aptitude scores

### 90-Day Placement Action Plan
**Month 1:** DSA + Aptitude foundation
**Month 2:** Projects + Resume building
**Month 3:** Mock interviews + Company research

**Use the Placement Assistant tool to get your detailed readiness score!**`;
}

function generateResumeResponse(msg: string): string {
  return `## Resume Analysis Guide

### ATS Optimization — Key Principles

**1. Format Requirements**
- Use a **single-column** layout for ATS compatibility
- Font: Arial, Calibri, or Times New Roman (10–12pt)
- No tables, graphics, or text boxes in ATS-submitted versions
- Save as **.pdf** (unless specified otherwise)

### Resume Sections (Priority Order)
1. **Contact Information** — Name, Phone, Email, LinkedIn, GitHub
2. **Summary/Objective** — 2–3 lines tailored to the role
3. **Skills** — Technical skills, tools, frameworks
4. **Education** — Degree, institution, CGPA, graduation year
5. **Projects** — 2–3 impactful projects with tech stack
6. **Internships/Experience** — If any
7. **Certifications** — Relevant to target role
8. **Achievements** — Hackathons, competitive programming, awards

### ATS Score Factors
| Factor | Impact |
|---|---|
| Keyword matching | High |
| Proper section headings | High |
| Consistent formatting | Medium |
| Quantified achievements | Medium |
| Grammar/spelling | High |

### Project Description Template
\`\`\`
[Project Name] | [Tech Stack] | [Year]
- Built [what] using [tech] that [achieved result]
- Implemented [feature] reducing [metric] by [X%]
- Deployed on [platform] serving [X] users
\`\`\`

### Common Mistakes to Avoid
- Spelling errors and grammatical mistakes
- Generic objective statements
- No quantification of achievements
- Inconsistent formatting
- Including irrelevant personal information

**Paste your resume content for a detailed ATS analysis and scoring!**`;
}

function generateAptitudeResponse(msg: string): string {
  return `## Aptitude Training Program

### 30-Day Preparation Plan

**Week 1: Quantitative Aptitude**
| Day | Topic | Questions/Day |
|---|---|---|
| 1–2 | Number System | 20 |
| 3–4 | Percentages & Ratios | 20 |
| 5–6 | Time, Speed & Distance | 20 |
| 7 | Revision + Mock | 40 |

**Week 2: Logical Reasoning**
| Day | Topic | Questions/Day |
|---|---|---|
| 8–9 | Series & Patterns | 20 |
| 10–11 | Blood Relations & Directions | 20 |
| 12–13 | Syllogisms & Puzzles | 20 |
| 14 | Revision + Mock | 40 |

**Week 3: Verbal Ability**
| Day | Topic | Questions/Day |
|---|---|---|
| 15–16 | Reading Comprehension | 15 |
| 17–18 | Sentence Correction | 20 |
| 19–20 | Fill in the Blanks | 20 |
| 21 | Revision + Mock | 40 |

**Week 4: Full Mock Tests**
- 2 full-length mock tests every day
- Analyze mistakes and rework weak areas
- Time management practice

### Practice Question — Quantitative
**Q:** A train 200m long travels at 60 km/h. How long does it take to cross a platform 100m long?

**Solution:**
\`\`\`
Total distance = 200 + 100 = 300m
Speed = 60 km/h = 60 × (1000/3600) = 16.67 m/s
Time = 300 / 16.67 = 18 seconds
\`\`\`

### Recommended Resources
- **R.S. Aggarwal** — Quantitative Aptitude
- **M.K. Pandey** — Analytical Reasoning
- **IndiaBix** — Free online practice
- **PrepInsta** — Company-specific questions

**Ask me to generate practice questions on any specific topic!**`;
}

function generateSkillsResponse(msg: string): string {
  return `## Skill Development Advisor

### High-Demand Skills in 2024

**Technical Skills**
| Skill | Demand | Avg Salary Impact | Time to Learn |
|---|---|---|---|
| Python | Very High | +20% | 2–3 months |
| React.js | High | +18% | 2–3 months |
| AWS/Cloud | Very High | +30% | 3–6 months |
| Machine Learning | High | +25% | 4–6 months |
| DevOps/Docker | High | +22% | 2–4 months |
| SQL/NoSQL | Very High | +15% | 1–2 months |

### Learning Resources (Free & Paid)

**Free Resources**
- **NPTEL** — IIT/IISc courses (best for academics)
- **freeCodeCamp** — Web development
- **Kaggle** — Data Science & ML
- **YouTube** — Traversy Media, Tech With Tim

**Paid (Worth It)**
- **Coursera** — Google/IBM/Meta certificates
- **Udemy** — Affordable specialized courses
- **LinkedIn Learning** — Professional skills

### Project Ideas by Domain
**Web Development:** E-commerce site, Blog platform, Task manager
**Data Science:** Sentiment analysis, Stock prediction, Recommendation system
**App Dev:** Expense tracker, Fitness app, Quiz application
**ML/AI:** Image classifier, Chatbot, Face recognition

### 6-Month Skill Building Plan
**Month 1–2:** Core language + fundamentals
**Month 3–4:** Framework/library deep dive
**Month 5:** Build 2 projects
**Month 6:** Open source + portfolio deployment

**Tell me your career goal and I'll create a personalized learning roadmap!**`;
}

const interviewQuestions: Record<string, string[]> = {
  python: [
    'What is the difference between a list and a tuple in Python?',
    'Explain Python decorators with an example.',
    'What is the GIL (Global Interpreter Lock) in Python?',
    'How does memory management work in Python?',
    'What is the difference between `is` and `==` in Python?',
    'Explain list comprehension vs generator expressions.',
    'What are Python\'s built-in data types?',
    'How do you handle exceptions in Python?',
  ],
  sql: [
    'What is the difference between INNER JOIN and OUTER JOIN?',
    'Explain the difference between WHERE and HAVING clauses.',
    'What is a subquery? Give an example.',
    'Explain database normalization (1NF, 2NF, 3NF).',
    'What is an index and how does it improve performance?',
    'What is the difference between DELETE, TRUNCATE, and DROP?',
    'Explain ACID properties in databases.',
    'What is a stored procedure?',
  ],
  dbms: [
    'What are the different types of database relationships?',
    'Explain the concept of functional dependency.',
    'What is a transaction? What are its properties?',
    'Explain the difference between a primary key and a foreign key.',
    'What is ER modeling? Explain its components.',
    'What is deadlock in databases? How is it prevented?',
    'Explain the B+ Tree data structure.',
    'What is the difference between DML and DDL?',
  ],
  os: [
    'What is the difference between a process and a thread?',
    'Explain the concept of deadlock and its four conditions.',
    'What is virtual memory and how does it work?',
    'Explain different CPU scheduling algorithms.',
    'What is the difference between semaphore and mutex?',
    'What is thrashing and how can it be prevented?',
    'Explain page replacement algorithms (LRU, FIFO, Optimal).',
    'What is the producer-consumer problem?',
  ],
  cn: [
    'Explain the OSI model and its 7 layers.',
    'What is the difference between TCP and UDP?',
    'What happens when you type a URL in a browser?',
    'Explain the TCP 3-way handshake.',
    'What is subnetting and CIDR notation?',
    'What is the difference between a router and a switch?',
    'Explain DNS and how domain name resolution works.',
    'What is ARP and how does it work?',
  ],
  dsa: [
    'What is the time complexity of binary search?',
    'Explain the difference between BFS and DFS.',
    'What is dynamic programming? Give an example.',
    'Explain quicksort with time complexity analysis.',
    'What is a hash table and how does collision resolution work?',
    'Explain the concept of a balanced binary search tree.',
    'What is the difference between a stack and a queue?',
    'How would you detect a cycle in a linked list?',
  ],
  aptitude: [
    'A train travels at 60 km/h. How long does it take to travel 240 km?',
    'If 5 workers can complete a job in 8 days, how many days for 10 workers?',
    'A number is increased by 20% and then decreased by 20%. What is the net change?',
    'Find the missing number in the series: 2, 6, 12, 20, 30, ?',
    'What is 15% of 280?',
    'A and B can do a piece of work in 12 and 18 days respectively. In how many days can they do it together?',
  ],
};

function generateInterviewResponse(
  msg: string,
  history: { role: string; content: string }[]
): string {
  const isFirstMessage = history.length <= 1;

  if (isFirstMessage || msg.includes('start') || msg.includes('begin') || msg.includes('ready')) {
    const domain = detectDomain(msg);
    const questions = interviewQuestions[domain] || interviewQuestions.dsa;
    const q = questions[0];
    return `## Technical Interview Started

**Domain:** ${domain.toUpperCase()}
**Mode:** Simulated Technical Interview

---

Welcome! I will be your interviewer today. I will ask you one question at a time, evaluate your answer, and provide detailed feedback.

---

**Question 1 of ${questions.length}:**

${q}

*Take your time to think through your answer. When ready, type your response.*`;
  }

  const lastAssistantMsg = [...history].reverse().find((m) => m.role === 'assistant');
  const questionMatch = lastAssistantMsg?.content.match(/\*\*Question \d+ of \d+:\*\*\s*\n\n(.+)/);
  const currentQuestion = questionMatch?.[1] || '';
  const qNumMatch = lastAssistantMsg?.content.match(/Question (\d+) of (\d+)/);
  const currentQNum = parseInt(qNumMatch?.[1] || '1');
  const totalQ = parseInt(qNumMatch?.[2] || '6');

  const domain = detectDomainFromHistory(history);
  const questions = interviewQuestions[domain] || interviewQuestions.dsa;
  const nextQ = questions[currentQNum] || null;

  let feedback = evaluateAnswer(msg, currentQuestion, domain);

  if (!nextQ || currentQNum >= totalQ - 1) {
    return `## Interview Feedback

**Your Answer:** "${msg.slice(0, 100)}${msg.length > 100 ? '...' : ''}"

${feedback}

---

## Interview Complete!

**Final Performance Summary:**

| Metric | Rating |
|---|---|
| Technical Knowledge | Good |
| Communication | Good |
| Problem-Solving Approach | Satisfactory |
| Overall Score | **72/100** |

**Strengths:**
- Showed understanding of core concepts
- Structured responses

**Areas to Improve:**
- Add more specific examples
- Practice time complexity analysis
- Use STAR method for behavioral questions

**Recommended Next Steps:**
1. Practice 5+ LeetCode problems daily
2. Review ${domain.toUpperCase()} fundamentals
3. Schedule another mock interview in 3 days

*Type "start" to begin a new interview session!*`;
  }

  return `## Interview Feedback

**Your Answer:** "${msg.slice(0, 80)}${msg.length > 80 ? '...' : ''}"

${feedback}

---

**Question ${currentQNum + 1} of ${totalQ}:**

${nextQ}

*Take your time. Type your answer when ready.*`;
}

function detectDomain(msg: string): string {
  if (msg.includes('python')) return 'python';
  if (msg.includes('sql')) return 'sql';
  if (msg.includes('dbms') || msg.includes('database')) return 'dbms';
  if (msg.includes('os') || msg.includes('operating')) return 'os';
  if (msg.includes('network') || msg.includes('cn')) return 'cn';
  if (msg.includes('aptitude')) return 'aptitude';
  return 'dsa';
}

function detectDomainFromHistory(history: { role: string; content: string }[]): string {
  const allContent = history.map((m) => m.content.toLowerCase()).join(' ');
  if (allContent.includes('python')) return 'python';
  if (allContent.includes('sql') && !allContent.includes('dbms')) return 'sql';
  if (allContent.includes('dbms') || allContent.includes('normalization')) return 'dbms';
  if (allContent.includes('operating system') || allContent.includes('process') || allContent.includes('thread')) return 'os';
  if (allContent.includes('osi') || allContent.includes('tcp') || allContent.includes('network')) return 'cn';
  if (allContent.includes('aptitude') || allContent.includes('train') || allContent.includes('km')) return 'aptitude';
  return 'dsa';
}

function evaluateAnswer(answer: string, question: string, domain: string): string {
  const wordCount = answer.split(' ').length;
  const isDetailed = wordCount > 30;
  const hasExample = answer.toLowerCase().includes('example') || answer.includes('e.g') || answer.includes('for instance');

  let score = 60;
  if (isDetailed) score += 15;
  if (hasExample) score += 10;
  if (wordCount > 60) score += 10;
  if (answer.length < 20) score = 30;

  const rating = score >= 80 ? 'Excellent' : score >= 65 ? 'Good' : score >= 50 ? 'Satisfactory' : 'Needs Improvement';

  return `**Evaluation:** ${rating} (${score}/100)

**Feedback:**
${isDetailed ? '+ Good detail level in your response.' : '- Try to provide more detail and explanation.'}
${hasExample ? '+ Great use of examples to illustrate your point.' : '- Consider adding concrete examples to strengthen your answer.'}
${wordCount > 60 ? '+ Comprehensive response.' : '- Elaborate more on the key aspects.'}

**Model Answer Hint:**
The key points to cover for this topic include the core definition, a practical example, and any relevant tradeoffs or use cases.`;
}
