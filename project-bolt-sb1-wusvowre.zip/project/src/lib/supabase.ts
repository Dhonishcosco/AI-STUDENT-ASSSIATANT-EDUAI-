import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type ChatSession = {
  id: string;
  mode: string;
  title: string;
  created_at: string;
  updated_at: string;
};

export type ChatMessage = {
  id: string;
  session_id: string;
  role: 'user' | 'assistant';
  content: string;
  metadata: Record<string, unknown>;
  created_at: string;
};

export type StudentProfile = {
  id: string;
  name: string;
  department: string;
  year_of_study: number;
  cgpa: number;
  skills: string[];
  interests: string[];
  certifications: string[];
  career_goals: string;
  internship_experience: string;
  projects: string[];
  created_at: string;
  updated_at: string;
};

export type StudyPlan = {
  id: string;
  subject: string;
  exam_date: string | null;
  daily_hours: number;
  available_days: number;
  schedule: StudyDay[];
  status: 'active' | 'completed' | 'paused';
  created_at: string;
};

export type StudyDay = {
  day: number;
  date?: string;
  topics: string[];
  hours: number;
  type: 'learn' | 'revise' | 'practice' | 'mock';
};

export type InterviewSession = {
  id: string;
  domain: string;
  questions: InterviewQA[];
  score: number | null;
  status: 'active' | 'completed';
  created_at: string;
};

export type InterviewQA = {
  question: string;
  answer?: string;
  feedback?: string;
  score?: number;
};

export type ProgressRecord = {
  id: string;
  category: 'skill' | 'certification' | 'project' | 'aptitude' | 'interview';
  title: string;
  description: string;
  status: 'in_progress' | 'completed';
  score: number | null;
  completed_at: string | null;
  created_at: string;
};
