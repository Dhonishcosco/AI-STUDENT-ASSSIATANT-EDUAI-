import { Bot, User } from 'lucide-react';
import { ChatMessage as ChatMessageType } from '../lib/supabase';

type Props = {
  message: ChatMessageType;
};

function parseMarkdown(text: string): string {
  return text
    // Code blocks
    .replace(/```(\w*)\n?([\s\S]*?)```/g, '<pre><code>$2</code></pre>')
    // Inline code
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    // Bold
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    // Headers
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^# (.+)$/gm, '<h2>$1</h2>')
    // HR
    .replace(/^---$/gm, '<hr />')
    // Tables
    .replace(/\|(.+)\|/g, (match) => {
      const cells = match.split('|').filter((c) => c.trim());
      return '<tr>' + cells.map((c) => {
        const content = c.trim();
        if (/^[-:]+$/.test(content)) return '';
        return `<td>${content}</td>`;
      }).join('') + '</tr>';
    })
    // Wrap table rows in table
    .replace(/((?:<tr>.*?<\/tr>\s*)+)/gs, (match) => {
      const rows = match.trim().split('\n').filter((r) => r.trim());
      if (rows.length === 0) return match;
      const firstRow = rows[0];
      const headerCells = firstRow.replace(/<td>/g, '<th>').replace(/<\/td>/g, '</th>');
      const bodyRows = rows.slice(1).join('\n');
      return `<table><thead>${headerCells}</thead><tbody>${bodyRows}</tbody></table>`;
    })
    // Unordered lists
    .replace(/^[-*+] (.+)$/gm, '<li>$1</li>')
    .replace(/((?:<li>.*?<\/li>\n?)+)/g, '<ul>$1</ul>')
    // Ordered lists
    .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
    // Blockquote
    .replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>')
    // Paragraphs — wrap lines not in any block element
    .replace(/^(?!<[a-z])(.+)$/gm, (match) => {
      if (match.trim()) return `<p>${match}</p>`;
      return match;
    })
    // Clean up empty paragraphs
    .replace(/<p><\/p>/g, '')
    .replace(/<p>\s*<\/p>/g, '');
}

export default function ChatMessage({ message }: Props) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <div className="flex items-end gap-3 justify-end animate-fade-in">
        <div className="max-w-[75%] bg-blue-600 text-white rounded-2xl rounded-br-sm px-4 py-3 text-sm leading-relaxed shadow-lg">
          {message.content}
        </div>
        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0 mb-0.5">
          <User size={14} className="text-slate-300" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-start gap-3 animate-fade-in">
      <div className="w-8 h-8 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center flex-shrink-0 mt-0.5">
        <Bot size={14} className="text-blue-400" />
      </div>
      <div className="flex-1 min-w-0 max-w-[85%]">
        <div className="card px-4 py-3 rounded-2xl rounded-tl-sm shadow-sm">
          <div
            className="markdown-content text-sm"
            dangerouslySetInnerHTML={{ __html: parseMarkdown(message.content) }}
          />
        </div>
      </div>
    </div>
  );
}

export function TypingIndicator() {
  return (
    <div className="flex items-center gap-3 animate-fade-in">
      <div className="w-8 h-8 rounded-full bg-blue-600/20 border border-blue-500/30 flex items-center justify-center flex-shrink-0">
        <Bot size={14} className="text-blue-400" />
      </div>
      <div className="card px-4 py-3 rounded-2xl rounded-tl-sm">
        <div className="flex gap-1.5 items-center">
          <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-2 h-2 rounded-full bg-blue-400 animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      </div>
    </div>
  );
}
