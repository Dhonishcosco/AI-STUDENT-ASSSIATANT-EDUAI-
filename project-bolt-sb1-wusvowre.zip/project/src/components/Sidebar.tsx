import {
  Bot,
  BookOpen,
  Briefcase,
  Target,
  FileText,
  Brain,
  Mic,
  Zap,
  BarChart3,
  User,
  ChevronLeft,
  ChevronRight,
  GraduationCap,
} from 'lucide-react';
import { NavMode } from '../types';

type NavItem = {
  id: NavMode;
  label: string;
  icon: React.FC<{ size?: number; className?: string }>;
  color: string;
  description: string;
};

const navItems: NavItem[] = [
  { id: 'chat', label: 'AI Assistant', icon: Bot, color: 'text-blue-400', description: 'General AI chat' },
  { id: 'study', label: 'Study Planner', icon: BookOpen, color: 'text-emerald-400', description: 'Plan your studies' },
  { id: 'career', label: 'Career Guidance', icon: Briefcase, color: 'text-amber-400', description: 'Career path advice' },
  { id: 'placement', label: 'Placement Prep', icon: Target, color: 'text-rose-400', description: 'Placement readiness' },
  { id: 'resume', label: 'Resume Analyzer', icon: FileText, color: 'text-purple-400', description: 'ATS & resume tips' },
  { id: 'aptitude', label: 'Aptitude Trainer', icon: Brain, color: 'text-cyan-400', description: 'Quant & reasoning' },
  { id: 'interview', label: 'Interview Trainer', icon: Mic, color: 'text-pink-400', description: 'Mock interviews' },
  { id: 'skills', label: 'Skill Development', icon: Zap, color: 'text-orange-400', description: 'Learn new skills' },
  { id: 'progress', label: 'Progress Tracker', icon: BarChart3, color: 'text-teal-400', description: 'Track your growth' },
  { id: 'profile', label: 'My Profile', icon: User, color: 'text-slate-400', description: 'Student profile' },
];

type Props = {
  activeMode: NavMode;
  onModeChange: (mode: NavMode) => void;
  collapsed: boolean;
  onToggle: () => void;
};

export default function Sidebar({ activeMode, onModeChange, collapsed, onToggle }: Props) {
  return (
    <aside
      className={`relative flex flex-col bg-slate-900 border-r border-slate-800 transition-all duration-300 ease-in-out flex-shrink-0 ${
        collapsed ? 'w-16' : 'w-60'
      }`}
    >
      {/* Logo */}
      <div className={`flex items-center gap-3 px-4 py-5 border-b border-slate-800 ${collapsed ? 'justify-center px-0' : ''}`}>
        <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center flex-shrink-0">
          <GraduationCap size={18} className="text-white" />
        </div>
        {!collapsed && (
          <div>
            <span className="font-display font-bold text-white text-base tracking-tight">EDUAI</span>
            <p className="text-xs text-slate-500 leading-none mt-0.5">Student Assistant</p>
          </div>
        )}
      </div>

      {/* Nav Items */}
      <nav className="flex-1 py-3 overflow-y-auto scrollbar-hide">
        <div className="space-y-0.5 px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeMode === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onModeChange(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 rounded-lg transition-all duration-150 group
                  ${collapsed ? 'justify-center px-0 py-3' : 'px-3 py-2.5'}
                  ${isActive
                    ? 'bg-blue-600/15 text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
              >
                <Icon
                  size={18}
                  className={`flex-shrink-0 transition-colors ${isActive ? item.color : ''}`}
                />
                {!collapsed && (
                  <div className="text-left min-w-0">
                    <p className={`text-sm font-medium truncate ${isActive ? 'text-white' : ''}`}>
                      {item.label}
                    </p>
                    <p className="text-xs text-slate-500 truncate hidden group-hover:block">
                      {item.description}
                    </p>
                  </div>
                )}
                {!collapsed && isActive && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-400 flex-shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Collapse toggle */}
      <div className="p-2 border-t border-slate-800">
        <button
          onClick={onToggle}
          className="w-full flex items-center justify-center py-2 rounded-lg text-slate-500 hover:text-slate-300 hover:bg-slate-800 transition-colors"
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>
    </aside>
  );
}
