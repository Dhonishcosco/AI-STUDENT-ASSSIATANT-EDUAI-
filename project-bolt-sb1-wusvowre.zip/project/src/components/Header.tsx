import { Bot, BookOpen, Briefcase, Target, FileText, Brain, Mic, Zap, BarChart3, User, Bell } from 'lucide-react';
import { NavMode } from '../types';

const modeConfig: Record<NavMode, { label: string; description: string; icon: React.FC<{ size?: number; className?: string }>; color: string; bg: string }> = {
  chat: { label: 'AI Assistant', description: 'Ask me anything about academics, career, or placement', icon: Bot, color: 'text-blue-400', bg: 'bg-blue-600/10' },
  study: { label: 'Study Planner', description: 'Generate personalized study plans for your exams', icon: BookOpen, color: 'text-emerald-400', bg: 'bg-emerald-600/10' },
  career: { label: 'Career Guidance', description: 'Discover the best career path for your profile', icon: Briefcase, color: 'text-amber-400', bg: 'bg-amber-600/10' },
  placement: { label: 'Placement Assistant', description: 'Evaluate your placement readiness score', icon: Target, color: 'text-rose-400', bg: 'bg-rose-600/10' },
  resume: { label: 'Resume Analyzer', description: 'Get ATS score and improvement suggestions', icon: FileText, color: 'text-purple-400', bg: 'bg-purple-600/10' },
  aptitude: { label: 'Aptitude Trainer', description: 'Master quantitative, logical and verbal skills', icon: Brain, color: 'text-cyan-400', bg: 'bg-cyan-600/10' },
  interview: { label: 'Interview Trainer', description: 'Practice mock technical interviews with AI feedback', icon: Mic, color: 'text-pink-400', bg: 'bg-pink-600/10' },
  skills: { label: 'Skill Development', description: 'Curated learning paths and resource recommendations', icon: Zap, color: 'text-orange-400', bg: 'bg-orange-600/10' },
  progress: { label: 'Progress Tracker', description: 'Monitor your growth and placement readiness', icon: BarChart3, color: 'text-teal-400', bg: 'bg-teal-600/10' },
  profile: { label: 'My Profile', description: 'Manage your student profile for personalized guidance', icon: User, color: 'text-slate-400', bg: 'bg-slate-600/10' },
};

type Props = {
  mode: NavMode;
};

export default function Header({ mode }: Props) {
  const config = modeConfig[mode];
  const Icon = config.icon;

  return (
    <header className="flex items-center gap-4 px-6 py-4 border-b border-slate-800 bg-slate-900/80 backdrop-blur-sm flex-shrink-0">
      <div className={`w-9 h-9 rounded-lg ${config.bg} flex items-center justify-center flex-shrink-0`}>
        <Icon size={18} className={config.color} />
      </div>
      <div className="min-w-0 flex-1">
        <h1 className="font-display font-semibold text-white text-base leading-tight">{config.label}</h1>
        <p className="text-xs text-slate-500 truncate">{config.description}</p>
      </div>
      <button className="w-8 h-8 rounded-lg hover:bg-slate-800 flex items-center justify-center text-slate-500 hover:text-slate-300 transition-colors relative flex-shrink-0">
        <Bell size={16} />
        <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-blue-500 rounded-full" />
      </button>
    </header>
  );
}
