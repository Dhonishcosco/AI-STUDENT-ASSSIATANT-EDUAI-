import { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import ChatAssistant from './pages/ChatAssistant';
import StudyPlanner from './pages/StudyPlanner';
import CareerGuidance from './pages/CareerGuidance';
import PlacementAssistant from './pages/PlacementAssistant';
import ResumeAnalyzer from './pages/ResumeAnalyzer';
import AptitudeTrainer from './pages/AptitudeTrainer';
import ProgressTracker from './pages/ProgressTracker';
import StudentProfilePage from './pages/StudentProfile';
import SkillDevelopment from './pages/SkillDevelopment';
import { NavMode } from './types';


export default function App() {
  const [mode, setMode] = useState<NavMode>('chat');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const renderContent = () => {
    switch (mode) {
      case 'chat':
        return <ChatAssistant mode="general" />;
      case 'study':
        return <StudyPlanner />;
      case 'career':
        return <CareerGuidance />;
      case 'placement':
        return <PlacementAssistant />;
      case 'resume':
        return <ResumeAnalyzer />;
      case 'aptitude':
        return <AptitudeTrainer />;
      case 'interview':
        return <ChatAssistant mode="interview" />;
      case 'skills':
        return <SkillDevelopment />;
      case 'progress':
        return <ProgressTracker />;
      case 'profile':
        return <StudentProfilePage />;
      default:
        return <ChatAssistant mode="general" />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      <Sidebar
        activeMode={mode}
        onModeChange={setMode}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed((c) => !c)}
      />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header mode={mode} />
        <main className="flex flex-1 min-h-0 overflow-hidden">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}
