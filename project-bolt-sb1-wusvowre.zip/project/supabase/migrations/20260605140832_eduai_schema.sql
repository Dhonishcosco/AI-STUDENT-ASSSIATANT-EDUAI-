/*
# EDUAI – AI Powered Student Assistant Schema

## Summary
Creates all tables needed for the EDUAI platform: chat history, student profiles,
study plans, interview sessions, and progress tracking. Single-tenant (no auth),
so anon + authenticated roles have full CRUD access.

## New Tables
- `chat_sessions` – conversation threads grouped by mode (study, career, interview, etc.)
- `chat_messages` – individual messages within a session (role: user|assistant)
- `student_profiles` – student info: name, dept, CGPA, skills, interests, goals
- `study_plans` – generated study plans with subject, timeline, schedule JSON
- `interview_sessions` – interview practice sessions with domain and score
- `progress_records` – skill/certification/project completion milestones

## Security
- RLS enabled on all tables
- anon + authenticated CRUD via USING(true) — intentionally public, single-tenant
*/

-- Chat sessions
CREATE TABLE IF NOT EXISTS chat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mode text NOT NULL DEFAULT 'general',
  title text NOT NULL DEFAULT 'New Conversation',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_select_chat_sessions" ON chat_sessions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_insert_chat_sessions" ON chat_sessions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_update_chat_sessions" ON chat_sessions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_delete_chat_sessions" ON chat_sessions FOR DELETE TO anon, authenticated USING (true);

-- Chat messages
CREATE TABLE IF NOT EXISTS chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS chat_messages_session_idx ON chat_messages(session_id, created_at);

ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_chat_messages" ON chat_messages;
CREATE POLICY "anon_select_chat_messages" ON chat_messages FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_chat_messages" ON chat_messages;
CREATE POLICY "anon_insert_chat_messages" ON chat_messages FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_chat_messages" ON chat_messages;
CREATE POLICY "anon_update_chat_messages" ON chat_messages FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_chat_messages" ON chat_messages;
CREATE POLICY "anon_delete_chat_messages" ON chat_messages FOR DELETE TO anon, authenticated USING (true);

-- Student profiles
CREATE TABLE IF NOT EXISTS student_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  department text NOT NULL DEFAULT '',
  year_of_study integer DEFAULT 1,
  cgpa numeric(4,2) DEFAULT 0,
  skills text[] DEFAULT '{}',
  interests text[] DEFAULT '{}',
  certifications text[] DEFAULT '{}',
  career_goals text DEFAULT '',
  internship_experience text DEFAULT '',
  projects text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE student_profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_student_profiles" ON student_profiles;
CREATE POLICY "anon_select_student_profiles" ON student_profiles FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_student_profiles" ON student_profiles;
CREATE POLICY "anon_insert_student_profiles" ON student_profiles FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_student_profiles" ON student_profiles;
CREATE POLICY "anon_update_student_profiles" ON student_profiles FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_student_profiles" ON student_profiles;
CREATE POLICY "anon_delete_student_profiles" ON student_profiles FOR DELETE TO anon, authenticated USING (true);

-- Study plans
CREATE TABLE IF NOT EXISTS study_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject text NOT NULL,
  exam_date date,
  daily_hours integer DEFAULT 4,
  available_days integer DEFAULT 30,
  schedule jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed', 'paused')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_study_plans" ON study_plans;
CREATE POLICY "anon_select_study_plans" ON study_plans FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_study_plans" ON study_plans;
CREATE POLICY "anon_insert_study_plans" ON study_plans FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_study_plans" ON study_plans;
CREATE POLICY "anon_update_study_plans" ON study_plans FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_study_plans" ON study_plans;
CREATE POLICY "anon_delete_study_plans" ON study_plans FOR DELETE TO anon, authenticated USING (true);

-- Interview sessions
CREATE TABLE IF NOT EXISTS interview_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  domain text NOT NULL,
  questions jsonb NOT NULL DEFAULT '[]',
  score integer,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'completed')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE interview_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_select_interview_sessions" ON interview_sessions FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_insert_interview_sessions" ON interview_sessions FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_update_interview_sessions" ON interview_sessions FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_delete_interview_sessions" ON interview_sessions FOR DELETE TO anon, authenticated USING (true);

-- Progress records
CREATE TABLE IF NOT EXISTS progress_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category text NOT NULL CHECK (category IN ('skill', 'certification', 'project', 'aptitude', 'interview')),
  title text NOT NULL,
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed')),
  score integer,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE progress_records ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_progress_records" ON progress_records;
CREATE POLICY "anon_select_progress_records" ON progress_records FOR SELECT TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_progress_records" ON progress_records;
CREATE POLICY "anon_insert_progress_records" ON progress_records FOR INSERT TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_progress_records" ON progress_records;
CREATE POLICY "anon_update_progress_records" ON progress_records FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_progress_records" ON progress_records;
CREATE POLICY "anon_delete_progress_records" ON progress_records FOR DELETE TO anon, authenticated USING (true);
