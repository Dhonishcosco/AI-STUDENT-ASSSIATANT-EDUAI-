/*
# Restrict RLS write policies to anon role only

## Summary
This is a single-tenant application with no user authentication. All six tables
previously granted INSERT, UPDATE, and DELETE access to both `anon` and `authenticated`
roles with an always-true condition. Since authenticated sessions do not exist in this
application, granting access to the `authenticated` role is unnecessary and expands
the attack surface.

## Changes
- All INSERT, UPDATE, DELETE policies on chat_sessions, chat_messages, student_profiles,
  study_plans, interview_sessions, and progress_records are rewritten to target
  `TO anon` only (removing `authenticated`).
- SELECT policies are also updated to `TO anon` only for consistency.
- No application behavior changes because no authenticated users exist in this app.

## Security
- Removes `authenticated` role from all write policies, so any accidentally-created
  authenticated session cannot modify data through these permissive always-true policies.
- `USING (true)` remains appropriate for the `anon` role in a single-tenant,
  no-authentication app where all data is intentionally shared within the session.
*/

-- ============================================================
-- chat_sessions
-- ============================================================
DROP POLICY IF EXISTS "anon_select_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_select_chat_sessions" ON chat_sessions
  FOR SELECT TO anon USING (true);

DROP POLICY IF EXISTS "anon_insert_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_insert_chat_sessions" ON chat_sessions
  FOR INSERT TO anon WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_update_chat_sessions" ON chat_sessions
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_chat_sessions" ON chat_sessions;
CREATE POLICY "anon_delete_chat_sessions" ON chat_sessions
  FOR DELETE TO anon USING (true);

-- ============================================================
-- chat_messages
-- ============================================================
DROP POLICY IF EXISTS "anon_select_chat_messages" ON chat_messages;
CREATE POLICY "anon_select_chat_messages" ON chat_messages
  FOR SELECT TO anon USING (true);

DROP POLICY IF EXISTS "anon_insert_chat_messages" ON chat_messages;
CREATE POLICY "anon_insert_chat_messages" ON chat_messages
  FOR INSERT TO anon WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_chat_messages" ON chat_messages;
CREATE POLICY "anon_update_chat_messages" ON chat_messages
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_chat_messages" ON chat_messages;
CREATE POLICY "anon_delete_chat_messages" ON chat_messages
  FOR DELETE TO anon USING (true);

-- ============================================================
-- student_profiles
-- ============================================================
DROP POLICY IF EXISTS "anon_select_student_profiles" ON student_profiles;
CREATE POLICY "anon_select_student_profiles" ON student_profiles
  FOR SELECT TO anon USING (true);

DROP POLICY IF EXISTS "anon_insert_student_profiles" ON student_profiles;
CREATE POLICY "anon_insert_student_profiles" ON student_profiles
  FOR INSERT TO anon WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_student_profiles" ON student_profiles;
CREATE POLICY "anon_update_student_profiles" ON student_profiles
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_student_profiles" ON student_profiles;
CREATE POLICY "anon_delete_student_profiles" ON student_profiles
  FOR DELETE TO anon USING (true);

-- ============================================================
-- study_plans
-- ============================================================
DROP POLICY IF EXISTS "anon_select_study_plans" ON study_plans;
CREATE POLICY "anon_select_study_plans" ON study_plans
  FOR SELECT TO anon USING (true);

DROP POLICY IF EXISTS "anon_insert_study_plans" ON study_plans;
CREATE POLICY "anon_insert_study_plans" ON study_plans
  FOR INSERT TO anon WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_study_plans" ON study_plans;
CREATE POLICY "anon_update_study_plans" ON study_plans
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_study_plans" ON study_plans;
CREATE POLICY "anon_delete_study_plans" ON study_plans
  FOR DELETE TO anon USING (true);

-- ============================================================
-- interview_sessions
-- ============================================================
DROP POLICY IF EXISTS "anon_select_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_select_interview_sessions" ON interview_sessions
  FOR SELECT TO anon USING (true);

DROP POLICY IF EXISTS "anon_insert_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_insert_interview_sessions" ON interview_sessions
  FOR INSERT TO anon WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_update_interview_sessions" ON interview_sessions
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_interview_sessions" ON interview_sessions;
CREATE POLICY "anon_delete_interview_sessions" ON interview_sessions
  FOR DELETE TO anon USING (true);

-- ============================================================
-- progress_records
-- ============================================================
DROP POLICY IF EXISTS "anon_select_progress_records" ON progress_records;
CREATE POLICY "anon_select_progress_records" ON progress_records
  FOR SELECT TO anon USING (true);

DROP POLICY IF EXISTS "anon_insert_progress_records" ON progress_records;
CREATE POLICY "anon_insert_progress_records" ON progress_records
  FOR INSERT TO anon WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_progress_records" ON progress_records;
CREATE POLICY "anon_update_progress_records" ON progress_records
  FOR UPDATE TO anon USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_progress_records" ON progress_records;
CREATE POLICY "anon_delete_progress_records" ON progress_records
  FOR DELETE TO anon USING (true);
